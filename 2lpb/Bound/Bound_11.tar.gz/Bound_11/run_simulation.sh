#!/usr/bin/env bash
set -euo pipefail

# File name prefixes
init="step3_input"
mini="step4.0_minimization"
equi="step4.1_equilibration"
prod_base="step5_production"
mdp_file="${prod_base}.mdp"

# Production range
start=1
end=10000

# Check for completion of a GROMACS stage
is_done() {
    [[ -f "$1.gro" && -f "$1.log" && -f "$1.edr" ]]
}

# Run a GROMACS stage
run_stage() {
    local stage="$1"
    local mdp="$2"
    local cgro="$3"
    local rgro="$4"

    echo "🔧 Running $stage..."
    gmx grompp -f "${mdp}.mdp" -o "${mdp}.tpr" -c "$cgro" ${rgro:+-r "$rgro"} -p topol.top -n index.ndx -maxwarn 10
    gmx mdrun -v -deffnm "$mdp"
    echo "✅ $stage complete."
}

echo "=== GROMACS Simulation Pipeline ==="

# Ensure required base files exist
for f in "$init.gro" "topol.top" "index.ndx"; do
    [[ -f $f ]] || { echo "❌ Required file missing: $f"; exit 1; }
done

# Minimization
if is_done "$mini"; then
    echo "✅ Minimization already done."
else
    run_stage "minimization" "$mini" "$init.gro" "$init.gro"
fi

# Equilibration
if is_done "$equi"; then
    echo "✅ Equilibration already done."
else
    run_stage "equilibration" "$equi" "${mini}.gro" "$init.gro"
fi

# Production loop
echo "=== Starting multi-step production from step $start to $end ==="
for ((i=start; i<=end; i++)); do
    tag="${prod_base}_${i}"

    if [[ -f "${tag}.gro" && -f "${tag}.log" && -f "${tag}.edr" ]]; then
        echo "✅ Production step $i already done."
        continue
    fi

    if [[ "$i" -eq 1 ]]; then
        input_gro="${equi}.gro"
    else
        prev=$((i - 1))
        input_gro="${prod_base}_${prev}.gro"
    fi

    [[ -f $input_gro ]] || { echo "❌ Cannot find input .gro for step $i: $input_gro"; exit 1; }

    echo "🚀 Running production step $i from $input_gro"
    gmx grompp -f "$mdp_file" -o "${tag}.tpr" -c "$input_gro" -p topol.top -n index.ndx -maxwarn 10
    gmx mdrun -v -deffnm "$tag"
    echo "✅ Production step $i complete."
done

echo "🎉 All GROMACS steps finished successfully."

