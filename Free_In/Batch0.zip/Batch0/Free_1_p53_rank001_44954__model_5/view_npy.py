#!/usr/bin/env python3
"""
view_npy.py: A simple utility to view the contents of an npy file.

Usage:
    ./view_npy.py <path_to_npy_file>

The script will load the file using numpy and pretty-print the contents.
It uses allow_pickle=True so that files storing dictionaries or other objects
can be loaded as well.
"""

import sys
import numpy as np
import pprint

def main():
    if len(sys.argv) != 2:
        print("Usage: view_npy.py <path_to_npy_file>")
        sys.exit(1)
    file_path = sys.argv[1]
    try:
        data = np.load(file_path, allow_pickle=True)
    except Exception as e:
        print(f"Error loading '{file_path}': {e}")
        sys.exit(1)
    
    # Check for common data types that need pretty-printing.
    if isinstance(data, (dict, list)):
        pprint.pprint(data)
    else:
        print(data)

if __name__ == "__main__":
    main()
