#!/usr/bin/env python3
import sys

def parse_pdb(pdb_file):
    atoms = []
    with open(pdb_file) as f:
        for line in f:
            if line.startswith("ATOM"):
                atoms.append(line)
    return atoms

def write_pdb(atoms, output_file):
    with open(output_file, 'w') as f:
        for atom in atoms:
            f.write(atom)

def create_capped_pdb(atoms):
    capped_atoms = []

    for line in atoms:
        res_num = int(line[22:26])
        atom_name = line[12:16].strip()

        # N-terminal ACE cap using residue 14
        if res_num == 14 and atom_name in ['CA', 'C', 'O']:
            ace_atom_name = {'CA': 'CH3', 'C': 'C', 'O': 'O'}[atom_name]
            new_line = f"{line[:12]}{ace_atom_name:<4} ACE A  14{line[26:]}"
            capped_atoms.append(new_line)

        # Residues 15-29 kept explicitly intact
        elif 15 <= res_num <= 29:
            capped_atoms.append(line)

        # C-terminal NME cap using residue 30
        elif res_num == 30 and atom_name in ['N', 'CA']:
            nme_atom_name = {'N': 'N', 'CA': 'CH3'}[atom_name]
            new_line = f"{line[:12]}{nme_atom_name:<4} NME A  30{line[26:]}"
            capped_atoms.append(new_line)

    return capped_atoms

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python cap_from_neighbors.py input.pdb output.pdb")
        sys.exit(1)

    input_pdb = sys.argv[1]
    output_pdb = sys.argv[2]

    atoms = parse_pdb(input_pdb)
    capped_atoms = create_capped_pdb(atoms)
    write_pdb(capped_atoms, output_pdb)

    print(f"Explicitly capped structure written to {output_pdb}")
