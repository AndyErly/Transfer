#!/usr/bin/env python3

import os
import re
import glob
import shutil
import subprocess
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import ttest_ind
import math

############################################
#           USER CONFIG SECTION            #
############################################

MAX_STEP = 1000  # We'll consider step*.edr up to step1000
ENERGY_TERMS = ["Potential", "Temperature", "Pressure", "Density"]
MERGED_EDR = "equilibrated.edr"
FINAL_DIR = "equilibration_check"
ANALYSIS_FILE = "analysis.txt"

# Number of data points (frames) to skip at the start, for all quantitative analyses
SKIP_POINTS = 5

############################################
#     1. Find EDR files up to step 1000    #
############################################

def get_chunk_number(fname):
    """If fname is 'stepXYZ.edr', return XYZ; else -1."""
    base = os.path.basename(fname)
    m = re.search(r"step(\d+)\.edr$", base)
    if m:
        return int(m.group(1))
    return -1

def invalid_keywords_in_fname(fname):
    """
    Return True if the filename indicates we should exclude it:
    specifically if it contains 'minimization' or 'equilibration'.
    """
    lower_name = fname.lower()
    # We skip if the filename has either substring
    if "minimization" in lower_name or "equilibration" in lower_name:
        return True
    return False

def find_edr_files_up_to_1000():
    """
    Look for step*.edr in . and group_1/ up to step1000,
    excluding any with 'minimization' or 'equilibration' in the name.
    Return sorted list of absolute paths.
    """
    candidates = []
    # Current directory
    for f in glob.glob("step*.edr"):
        candidates.append(os.path.abspath(f))
    # group_1 subdir
    if os.path.isdir("group_1"):
        for f in glob.glob(os.path.join("group_1", "step*.edr")):
            candidates.append(os.path.abspath(f))

    valid = []
    for path in candidates:
        fname = os.path.basename(path)
        # Exclude filenames if they mention 'minimization' or 'equilibration'
        if invalid_keywords_in_fname(fname):
            continue

        cnum = get_chunk_number(path)
        if 1 <= cnum <= MAX_STEP:
            valid.append(path)

    valid.sort(key=lambda x: get_chunk_number(x))
    return valid

############################################
#      2. Merge EDR files => .edr          #
############################################

def merge_edr_files(edr_files, merged_edr):
    """
    Merge edr_files -> merged_edr using gmx eneconv -quiet.
    """
    if not edr_files:
        print("No EDR files found up to step 1000 (or all excluded). Exiting.")
        return False
    cmd = ["gmx", "eneconv", "-quiet", "-f"] + edr_files + ["-o", merged_edr]
    print(f"Merging {len(edr_files)} EDR files up to step {MAX_STEP} into {merged_edr}...")
    ret = subprocess.run(cmd, capture_output=True, text=True)
    if ret.returncode != 0:
        print(f"ERROR merging EDR:\n{ret.stderr}")
        return False
    return True

############################################
#  3. Extract properties via gmx energy    #
############################################

def extract_property_from_edr(prop_name, edr_file):
    """
    Extract time vs. prop_name from edr_file => <prop_name>.xvg
    """
    xvg_out = f"{prop_name.lower()}.xvg"
    input_data = f"{prop_name}\n0\n"
    cmd = f'echo -e "{input_data}" | gmx energy -f "{edr_file}" -o "{xvg_out}"'
    print(f"Extracting '{prop_name}' -> {xvg_out} ...")
    ret = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if ret.returncode != 0:
        print(f"WARNING: Could not extract '{prop_name}' from {edr_file}:\n{ret.stderr}")
        return None
    if not os.path.exists(xvg_out):
        return None
    return xvg_out

def parse_xvg_file(xvg_path):
    """
    Parse 2-column .xvg => (time[], value[]) as numpy arrays.
    """
    times, vals = [], []
    with open(xvg_path, 'r') as f:
        for line in f:
            if line.startswith('#') or line.startswith('@'):
                continue
            parts = line.split()
            if len(parts) < 2:
                continue
            try:
                t = float(parts[0])
                v = float(parts[1])
                times.append(t)
                vals.append(v)
            except ValueError:
                pass
    return np.array(times), np.array(vals)

############################################
#   4. Plot, highlighting first SKIP points
############################################

def plot_property(times, vals, prop_name):
    """
    Plot time vs. property => <prop_name>.png
    First SKIP_POINTS data (if available) in red ("Skipped region"),
    the rest in blue ("Analysis region").
    """
    if len(times) == 0:
        print(f"No data to plot for '{prop_name}'.")
        return

    plt.figure()
    if len(times) <= SKIP_POINTS:
        plt.plot(times, vals, color="red", label="Skipped region (all data)")
    else:
        plt.plot(times[:SKIP_POINTS], vals[:SKIP_POINTS],
                 color="red", label="Skipped region")
        plt.plot(times[SKIP_POINTS:], vals[SKIP_POINTS:],
                 color="blue", label="Analysis region")

    plt.xlabel("Time (ps)")
    plt.ylabel(prop_name)
    plt.title(f"{prop_name} vs Time (up to step {MAX_STEP})")
    plt.legend()
    out_png = f"{prop_name.lower()}.png"
    plt.savefig(out_png, dpi=120)
    plt.close()
    print(f"Created plot: {out_png}")

############################################
#   5. Skip first SKIP_POINTS for analysis #
############################################

def skip_initial_points(times, vals, skip=SKIP_POINTS):
    """
    Return (times[skip:], vals[skip:]) if possible; else empty arrays.
    """
    if len(vals) <= skip:
        return np.array([]), np.array([])
    return times[skip:], vals[skip:]

############################################
#          QUANTITATIVE ANALYSES           #
############################################

def block_average_analysis(vals, n_blocks=5):
    """
    Partition 'vals' into n_blocks. Return list of block means.
    """
    N = len(vals)
    block_size = N // n_blocks
    means = []
    start = 0
    for i in range(n_blocks):
        end = start + block_size
        if i == n_blocks - 1:  # last block takes remainder
            end = N
        block_data = vals[start:end]
        if len(block_data) > 0:
            means.append(np.mean(block_data))
        else:
            means.append(np.nan)
        start = end
    return means

def running_average(vals):
    """
    Return array R where R[i] = mean(vals[:i+1]).
    """
    csum = np.cumsum(vals)
    idxs = np.arange(1, len(vals)+1)
    return csum / idxs

def ttest_early_late(vals):
    """
    Compare first half vs. second half => (t, p).
    """
    half = len(vals)//2
    early = vals[:half]
    late  = vals[half:]
    if len(early) < 2 or len(late) < 2:
        return None, None
    t, p = ttest_ind(early, late, equal_var=False)
    return t, p

############################################
#     ROBUST FFT-BASED AUTOCORRELATION     #
############################################

def compute_autocorrelation_fft(x):
    """
    Compute autocorrelation of x (length N) using FFT-based method:
    1) Subtract mean
    2) Zero-pad to at least 2*N to avoid wraparound
    3) ACF = ifft( FFT(x) * conj(FFT(x)) )
    4) Normalize so that ACF[0] = 1
    Returns acf array of length N: [ACF(0), ACF(1), ..., ACF(N-1)]
    """
    N = len(x)
    if N < 2:
        return np.array([])

    xmean = np.mean(x)
    x0 = x - xmean
    size = 2 * N
    xpad = np.zeros(size, dtype=float)
    xpad[:N] = x0

    X = np.fft.fft(xpad)
    S = X * np.conjugate(X)
    raw_acf = np.fft.ifft(S)
    raw_acf = np.real(raw_acf[:N])

    # normalize so ACF(0) = 1
    acf = raw_acf / raw_acf[0]
    return acf

def compute_correlation_time(vals, times):
    """
    Estimate correlation time by:
    1) acf = compute_autocorrelation_fft(vals)
    2) find first lag i for which acf[i] < 1/e
    3) tau ~ i * dt, dt ~ median dt from times
    """
    n = len(vals)
    if n < 5:
        return None

    acf = compute_autocorrelation_fft(vals)
    if len(acf) < 2:
        return None

    dt_array = np.diff(times)
    if len(dt_array) < 1:
        return None
    dt = np.median(dt_array)

    threshold = 1.0 / math.e
    for i in range(len(acf)):
        if acf[i] < threshold:
            return i * dt

    return None  # never dropped below 1/e

############################################
# INTEGRATING IT INTO THE EQUIL ANALYSIS   #
############################################

def analyze_equilibration(prop_name, times, vals):
    """
    Perform block means, running avg, t-test, correlation time,
    ignoring the first SKIP_POINTS (already removed if skip was called).
    Format your requested style.
    """
    lines = []
    lines.append(f"==== Quantitative Equilibration Analysis ({prop_name}) ====")

    n = len(vals)
    if n < 5:
        lines.append(f"Not enough data for analysis on {prop_name}. Only {n} samples after skip.")
        lines.append("=========================================================")
        return "\n".join(lines)

    # 1) Block means
    bmeans = block_average_analysis(vals, n_blocks=5)
    lines.append(f"Block means (5 equally sized blocks): {bmeans}")

    # 2) Running average
    ravg = running_average(vals)
    half_idx = n // 2
    final_avg = ravg[-1]
    mid_avg   = ravg[half_idx]
    diff = abs(final_avg - mid_avg)

    lines.append(f"Running average at halfway point: {mid_avg:.4f}")
    lines.append(f"Running average at end:          {final_avg:.4f}")
    lines.append(f"Difference:                     {diff:.2f}")

    # 3) T-test (early vs late)
    t_val, p_val = ttest_early_late(vals)
    if t_val is None or p_val is None:
        lines.append("Not enough data for T-test or partitioning error.")
    else:
        lines.append(f"Earliest half vs. latest half T-test: t={t_val:.3f}, p={p_val:.3g}")
        if p_val > 0.05:
            lines.append("No significant difference => likely equilibrated by that measure.")
        else:
            lines.append("Significant difference => might NOT be fully equilibrated yet.")

    # 4) Correlation time (FFT-based)
    tau = compute_correlation_time(vals, times)
    if tau is not None:
        lines.append(f"Estimated correlation time (1/e method): {tau:.3f} ps")
    else:
        lines.append("Correlation time could not be determined (too short data or zero variance).")

    lines.append("=========================================================")
    return "\n".join(lines)

############################################
#         MOVE RESULTS TO FINAL_DIR        #
############################################

def move_results_to_dir(dir_name=FINAL_DIR, merged_edr=MERGED_EDR, analysis_file=ANALYSIS_FILE):
    os.makedirs(dir_name, exist_ok=True)

    # Move .edr
    if os.path.exists(merged_edr):
        shutil.move(merged_edr, os.path.join(dir_name, merged_edr))

    # Move .xvg / .png
    for f in os.listdir('.'):
        if f.endswith('.xvg') or f.endswith('.png'):
            shutil.move(f, os.path.join(dir_name, f))

    # Move analysis file
    if os.path.exists(analysis_file):
        shutil.move(analysis_file, os.path.join(dir_name, analysis_file))

############################################
#                  MAIN                    #
############################################

def main():
    # 1. Find EDR up to step1000 in . and group_1/ (excluding minimization/equilibration)
    edr_files = find_edr_files_up_to_1000()
    if not edr_files:
        print("No EDR files up to step 1000 in . or group_1/ (or all excluded). Exiting.")
        return

    print("Found EDR files (<= step 1000), excluding minimization/equilibration:")
    for f in edr_files:
        print("  ", f)

    # 2. Merge them
    success = merge_edr_files(edr_files, MERGED_EDR)
    if not success:
        return

    # 3. Extract, parse, plot
    data_dict = {}
    for prop in ENERGY_TERMS:
        xvg_file = extract_property_from_edr(prop, MERGED_EDR)
        if xvg_file is None:
            continue
        times, vals = parse_xvg_file(xvg_file)
        if len(times) < 1:
            print(f"No data for {prop} in {xvg_file}.")
            continue

        # Produce a 2-color plot showing the first SKIP_POINTS in red, rest in blue
        plot_property(times, vals, prop)

        # Now skip first SKIP_POINTS for analysis
        times_skipped, vals_skipped = skip_initial_points(times, vals, SKIP_POINTS)
        data_dict[prop] = (times_skipped, vals_skipped)

    # 4. Analyze each property, gather text
    all_analysis = []
    for prop, (tarr, varr) in data_dict.items():
        text = analyze_equilibration(prop, tarr, varr)
        print(text)  # console
        all_analysis.append(text)

    # Write text to analysis.txt locally
    with open(ANALYSIS_FILE, "w") as af:
        for section in all_analysis:
            af.write(section + "\n")

    # 5. Move everything to equilibration_check
    move_results_to_dir()

if __name__ == "__main__":
    main()

