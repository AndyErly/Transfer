#!/usr/bin/env python3
import os
import sys
import time
import json
import subprocess
import re
import glob
import shutil
import pickle
import tarfile
import numpy as np
import pandas as pd
import mdtraj as md
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from concurrent.futures import ThreadPoolExecutor, wait

##############################################################################
#                               USER CONFIG                                  #
##############################################################################

DEBUG = True

N_CHUNKS = 5000              # Total number of chunks to run
EQUILIBRATION_CHUNKS = 1000  # Chunks considered equilibration (data collection starts after this)
MDP_FILE = "step5_production.mdp"
TOPOL    = "topol.top"
INDEX    = "index.ndx"
EQUI_PREFIX = "step4.1_equilibration"

ROTAMER_CONFIG_FILE = "Analysis/rotamer_config_trinary.json"
RAMA_CSV_DIR        = "Analysis/merged_plots"
OUTPUT_DIR          = "analysis_output"

# Instead of CSV files, we now output NPY files.
MASTER_NPY = os.path.join(OUTPUT_DIR, "master_conformations.npy")
UNIQUE_KEYS_NPY = os.path.join(OUTPUT_DIR, "unique_keys_by_chunk.npy")
UNIQUE_KEYS_PNG = os.path.join(OUTPUT_DIR, "unique_keys_by_chunk.png")

UNIQUE_KEYS_FILTERED_NPY = os.path.join(OUTPUT_DIR, "unique_keys_by_chunk_filtered.npy")
UNIQUE_KEYS_FILTERED_PNG = os.path.join(OUTPUT_DIR, "unique_keys_by_chunk_filtered.png")

# New unique key tracking for keys without chi2.
UNIQUE_KEYS_NO_CHI2_NPY = os.path.join(OUTPUT_DIR, "unique_keys_by_chunk_no_chi2.npy")
UNIQUE_KEYS_NO_CHI2_PNG = os.path.join(OUTPUT_DIR, "unique_keys_by_chunk_no_chi2.png")
UNIQUE_KEYS_FILTERED_NO_CHI2_NPY = os.path.join(OUTPUT_DIR, "unique_keys_by_chunk_filtered_no_chi2.npy")
UNIQUE_KEYS_FILTERED_NO_CHI2_PNG = os.path.join(OUTPUT_DIR, "unique_keys_by_chunk_filtered_no_chi2.png")

# Full trajectories are kept (downsampling removed).

# For the sidechain COM histogram:
# Bins from 0 to 20 Å with 0.1 Å bins (201 edges -> 200 bins per dimension)
HISTOGRAM_BIN_EDGES = np.linspace(0, 20, 201)

# Temperature (K) and Boltzmann constant (kcal/mol*K)
TEMPERATURE = 310.15
kB = 0.0019872041

# Global dictionaries for conformation statistics.
CONFORMATION_STATS = {}
FILTERED_STATS = {}

# Dictionaries for keys without chi2.
CONFORMATION_STATS_NO_CHI2 = {}
FILTERED_STATS_NO_CHI2 = {}

# Global master histogram for sidechain COM distances.
MASTER_HIST = np.zeros((len(HISTOGRAM_BIN_EDGES)-1,
                        len(HISTOGRAM_BIN_EDGES)-1,
                        len(HISTOGRAM_BIN_EDGES)-1), dtype=float)

# Prefix for group directories.
GROUP_DIR_PREFIX = "group_"

AA_THREE_TO_ONE = {
    "ALA": "A", "ARG": "R", "ASN": "N", "ASP": "D", "CYS": "C",
    "GLN": "Q", "GLU": "E", "GLY": "G", "HIS": "H", "ILE": "I",
    "LEU": "L", "LYS": "K", "MET": "M", "PHE": "F", "PRO": "P",
    "SER": "S", "THR": "T", "TRP": "W", "TYR": "Y", "VAL": "V"
}

# Backbone atoms to exclude for sidechain COM.
BACKBONE_ATOMS = {"N", "CA", "C", "O"}

# --- Global Variables for φ/ψ Histogramming ---
PHI_PSI_BINS = 360  # Bin size (in degrees)
PHI_PSI_HISTS = {}  # {residue index: 2D histogram (360x360)}

# File to store the global baseline energy.
GLOBAL_MIN_ENERGY_FILE = "global_min_energy.txt"

##############################################################################
#                        DEBUGGING RESIDUE INFORMATION                       #
##############################################################################

def debug_residues_info():
    gro_file = EQUI_PREFIX + ".gro"
    if not os.path.exists(gro_file):
        print("Equilibration structure file not found; cannot load residue info for debugging.")
        return
    try:
        traj = md.load(gro_file)
    except Exception as e:
        print("Failed to load equilibration structure:", e)
        return
    print("Debug: First 130 residues info:")
    for residue in traj.topology.residues:
        if residue.index > 130:
            break
        print(f"Residue {residue.index}: {residue.name}")
        rama_file = os.path.join(RAMA_CSV_DIR, f"rama_{residue.name}{residue.index}_merged.csv")
        if os.path.exists(rama_file):
            print(f"  Rama file: {rama_file}")
        else:
            print("  Rama file: Not found")
        # Optionally print rotamer config info for this residue.
    # In free state, COM residues were chosen from indices 5,9,12.
    # (This is free-state; do not confuse with the bound-state numbering.)
    com_residues = [5, 9, 12]
    print("\nDebug: Residues selected for COM analysis:")
    for res in traj.topology.residues:
        if res.index in com_residues:
            print(f"  Residue {res.index}: {res.name} (from topology)")

##############################################################################
#                 DEBUG ROTAMER CONFIGURATION (JSON)                       #
##############################################################################

def debug_rotamer_config():
    if os.path.exists(ROTAMER_CONFIG_FILE):
        try:
            with open(ROTAMER_CONFIG_FILE, "r") as f:
                config = json.load(f)
            print("DEBUG: Rotamer configuration loaded from JSON:")
            for residue, res_data in config.items():
                print(f"Residue {residue}:")
                for chi in ["chi1", "chi2"]:
                    if chi in res_data:
                        boundaries = res_data[chi].get("boundaries", [])
                        labels = res_data[chi].get("labels", [])
                        print(f"  {chi}: boundaries = {boundaries}, labels = {labels}")
                    else:
                        print(f"  {chi}: Not found")
        except Exception as e:
            print(f"Error reading rotamer config: {e}")
    else:
        print("DEBUG: Rotamer config file not found.")

##############################################################################
#                    GLOBAL MINIMUM ENERGY HANDLING                              #
##############################################################################
MIN_ENERGY = None

def load_global_min_energy():
    global MIN_ENERGY
    if os.path.exists(GLOBAL_MIN_ENERGY_FILE):
        try:
            with open(GLOBAL_MIN_ENERGY_FILE, "r") as f:
                MIN_ENERGY = float(f.read().strip())
            if DEBUG:
                print(f"Loaded global MIN_ENERGY = {MIN_ENERGY} from {GLOBAL_MIN_ENERGY_FILE}")
        except Exception as e:
            print(f"Error loading {GLOBAL_MIN_ENERGY_FILE}: {e}")

def save_global_min_energy(energy):
    try:
        with open(GLOBAL_MIN_ENERGY_FILE, "w") as f:
            f.write(f"{energy}")
        if DEBUG:
            print(f"Saved global MIN_ENERGY = {energy} to {GLOBAL_MIN_ENERGY_FILE}")
    except Exception as e:
        print(f"Error saving {GLOBAL_MIN_ENERGY_FILE}: {e}")

def determine_global_minimum():
    edr_files = []
    while not edr_files:
        edr_files += glob.glob("step*.edr")
        edr_files += glob.glob(os.path.join("group_1", "step*.edr"))
        filtered = []
        for f in edr_files:
            m = re.search(r"step(\d+)\.edr", os.path.basename(f))
            if m:
                chunk_num = int(m.group(1))
                if chunk_num <= EQUILIBRATION_CHUNKS:
                    filtered.append(f)
        edr_files = filtered
        if not edr_files:
            print("No edr files from steps 1-1000 found. Waiting 60 seconds...")
            time.sleep(60)
    global_min = None
    for f in edr_files:
        times, pots = parse_potential(f)
        if len(pots) == 0:
            continue
        file_min = np.min(pots)
        if global_min is None or file_min < global_min:
            global_min = file_min
    return global_min

def load_or_determine_global_minimum():
    if os.path.exists(GLOBAL_MIN_ENERGY_FILE):
        try:
            with open(GLOBAL_MIN_ENERGY_FILE, "r") as f:
                value = float(f.read().strip())
            print(f"Loaded global MIN_ENERGY = {value} from {GLOBAL_MIN_ENERGY_FILE}")
            return value
        except Exception as e:
            print(f"Error reading global minimum file: {e}")
    print("Global minimum file not found. Determining global minimum from edr files (steps 1-1000)...")
    global_min = determine_global_minimum()
    if global_min is not None:
        with open(GLOBAL_MIN_ENERGY_FILE, "w") as f:
            f.write(f"{global_min}")
        print(f"Determined and saved global MIN_ENERGY = {global_min}")
    else:
        print("Could not determine global minimum from edr files.")
    return global_min

def boltzmann_factor(energy):
    global MIN_ENERGY
    if MIN_ENERGY is None:
        MIN_ENERGY = energy
        if DEBUG:
            print(f"Setting MIN_ENERGY to {MIN_ENERGY}")
        save_global_min_energy(MIN_ENERGY)
    reduced_val = (energy - MIN_ENERGY) / (kB * TEMPERATURE)
    exponent = -reduced_val
    factor = np.exp(exponent)
    if np.isinf(factor):
        print(f"Overflow detected: energy = {energy}, MIN_ENERGY = {MIN_ENERGY}")
    if DEBUG and np.isclose(factor, 0.0):
        print(f"DEBUG: Boltzmann factor is zero or nearly zero: energy = {energy}, MIN_ENERGY = {MIN_ENERGY}, reduced = {reduced_val}, exponent = {exponent}")
    return factor

##############################################################################
#                           GROMACS RUN                                      #
##############################################################################
def run_command(cmd: str):
    p = subprocess.run(cmd, shell=True, text=True, capture_output=True)
    if p.returncode != 0:
        print(f"ERROR:\n{p.stderr}")
        sys.exit(1)

def grompp_and_mdrun(chunk_i, prev_prefix):
    step_prefix = f"step{chunk_i}"
    gro_in = f"{prev_prefix}.gro"
    cpt_in = f"{prev_prefix}.cpt"
    grompp_cmd = f"gmx grompp -f {MDP_FILE} -c {gro_in} -p {TOPOL} -n {INDEX} -o {step_prefix}.tpr"
    if os.path.exists(cpt_in):
        grompp_cmd += f" -t {cpt_in}"
    run_command(grompp_cmd)
    mdrun_cmd = f"gmx mdrun -s {step_prefix}.tpr -deffnm {step_prefix}"
    run_command(mdrun_cmd)

##############################################################################
#                         ENERGY PARSING                                     #
##############################################################################
def parse_potential(edr_file: str):
    if not os.path.exists(edr_file):
        return np.array([]), np.array([])
    tmp_xvg = "temp_energy.xvg"
    cmd = f'echo Potential | gmx energy -f {edr_file} -o {tmp_xvg}'
    p = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if p.returncode != 0:
        return np.array([]), np.array([])
    times, pots = [], []
    with open(tmp_xvg, "r") as f:
        for line in f:
            if line.startswith(("#", "@")):
                continue
            cols = line.split()
            if len(cols) >= 2:
                times.append(float(cols[0]))
                pots.append(float(cols[1]))
    if os.path.exists(tmp_xvg):
        os.remove(tmp_xvg)
    return np.array(times), np.array(pots)

def nearest_potential(t_ps, timesE, potsE):
    if len(timesE) == 0:
        return 0.0
    idx = np.argmin(np.abs(timesE - t_ps))
    return potsE[idx]

##############################################################################
#                           RAMA CSV HELPER                                  #
##############################################################################
def load_rama_csv(res_name, csv_res_num):
    if not (1 <= csv_res_num <= 15):
        return None
    # For free state, CSV filenames use the residue name and number directly.
    csvfile = f"rama_{res_name}{csv_res_num}_merged.csv"
    fullpath = os.path.join(RAMA_CSV_DIR, csvfile)
    if not os.path.exists(fullpath):
        return None
    return pd.read_csv(fullpath)

def get_rama_label(phi_deg, psi_deg, df):
    if df is None or psi_deg is None:
        return "??"
    # For free-state, CSVs are binned in 5° increments.
    phi_bin = int((phi_deg + 180) // 5)
    psi_bin = int((psi_deg + 180) // 5)
    phi_bin = max(0, min(71, phi_bin))
    psi_bin = max(0, min(71, psi_bin))
    row = df.loc[(df.x == phi_bin) & (df.y == psi_bin)]
    if len(row) == 0:
        return "??"
    label = str(row.iloc[0]['label'])
    if len(label) == 1:
        label = '0' + label
    elif len(label) == 0:
        label = '??'
    return label[:2]

##############################################################################
#                    OMEGA & CHI1/CHI2 FINDING                             #
##############################################################################
def find_omega_index_for_residue(res_i, om_i, topology):
    next_res = res_i + 1
    for idx, (a1, a2, a3, a4) in enumerate(om_i):
        rset = {topology.atom(a1).residue.index,
                topology.atom(a2).residue.index,
                topology.atom(a3).residue.index,
                topology.atom(a4).residue.index}
        if (res_i in rset) and (next_res in rset):
            return idx
    return None

def get_omega_angle_for_residue(traj, frame_idx, res_i, om_i, om_v):
    row_idx = find_omega_index_for_residue(res_i, om_i, traj.topology)
    if row_idx is None or row_idx >= om_v.shape[1]:
        return None
    try:
        angle = np.degrees(om_v[frame_idx, row_idx])
    except IndexError:
        return None
    return angle

def find_chi1_index_for_residue(res_i, chi1_i, topology):
    for idx, (a1, a2, a3, a4) in enumerate(chi1_i):
        rset = {topology.atom(a1).residue.index,
                topology.atom(a2).residue.index,
                topology.atom(a3).residue.index,
                topology.atom(a4).residue.index}
        if len(rset) == 1 and (res_i in rset):
            return idx
    return None

def get_chi1_angle_for_residue(traj, frame_idx, res_i, chi1_i, chi1_v):
    row_idx = find_chi1_index_for_residue(res_i, chi1_i, traj.topology)
    if row_idx is None or row_idx >= chi1_v.shape[1]:
        return None
    try:
        angle = np.degrees(chi1_v[frame_idx, row_idx])
    except IndexError:
        return None
    return ((angle + 180) % 360) - 180

def find_chi2_index_for_residue(res_i, chi2_i, topology):
    for idx, (a1, a2, a3, a4) in enumerate(chi2_i):
        rset = {topology.atom(a1).residue.index,
                topology.atom(a2).residue.index,
                topology.atom(a3).residue.index,
                topology.atom(a4).residue.index}
        if len(rset) == 1 and (res_i in rset):
            return idx
    return None

def get_chi2_angle_for_residue(traj, frame_idx, res_i, chi2_i, chi2_v):
    row_idx = find_chi2_index_for_residue(res_i, chi2_i, traj.topology)
    if row_idx is None or row_idx >= chi2_v.shape[1]:
        return None
    try:
        angle = np.degrees(chi2_v[frame_idx, row_idx])
    except IndexError:
        return None
    return ((angle + 180) % 360) - 180

##############################################################################
#                    SIDECHAIN COM & HISTOGRAM COMPUTATION                   #
##############################################################################
def compute_sidechain_com(traj, res_id):
    atoms = [atom for atom in traj.topology.atoms 
             if atom.residue.index == res_id and 
             atom.name not in BACKBONE_ATOMS and 
             (atom.element is None or atom.element.symbol.upper() != "H")]
    if not atoms:
        return None
    indices = [atom.index for atom in atoms]
    com = np.mean(traj.xyz[:, indices, :], axis=1)
    return com

def compute_sidechain_histogram(traj):
    com5 = compute_sidechain_com(traj, 5)
    com9 = compute_sidechain_com(traj, 9)
    com12 = compute_sidechain_com(traj, 12)
    if com5 is None or com9 is None or com12 is None:
        return None
    d5_9 = np.linalg.norm(com5 - com9, axis=1)
    d5_12 = np.linalg.norm(com5 - com12, axis=1)
    d9_12 = np.linalg.norm(com9 - com12, axis=1)
    distances = np.vstack((d5_9, d5_12, d9_12)).T
    hist, edges = np.histogramdd(distances, bins=[HISTOGRAM_BIN_EDGES]*3)
    return hist, edges

##############################################################################
#                    COMPUTE DIHEDRAL ANGLES (INCLUDING CHI2)               #
##############################################################################
def compute_phi_psi_chi1_chi2_omega(traj):
    phi_i, phi_v = md.compute_phi(traj)
    psi_i, psi_v = md.compute_psi(traj)
    chi1_i, chi1_v = md.compute_chi1(traj)
    chi2_i, chi2_v = md.compute_chi2(traj)
    om_i, om_v = md.compute_omega(traj)
    return phi_i, phi_v, psi_i, psi_v, chi1_i, chi1_v, chi2_i, chi2_v, om_i, om_v

##############################################################################
#                    CLASSIFY CONFORMATION                                   #
##############################################################################
def classify_conformation(traj, frame_idx,
                          phi_i, phi_v, psi_i, psi_v,
                          chi1_i, chi1_v, chi2_i, chi2_v,
                          om_i, om_v,
                          rotamer_config, debug=False):
    full_parts = []
    full_parts_no_chi2 = []
    filtered_parts = []
    filtered_parts_no_chi2 = []
    n = min(len(phi_i), phi_v.shape[1], len(psi_i), psi_v.shape[1])
    for i in range(n):
        a1, a2, a3, a4 = phi_i[i]
        residue = traj.topology.atom(a2).residue
        rname = residue.name
        rnum  = residue.index
        csv_res_num = rnum
        df_rama = load_rama_csv(rname, csv_res_num)
        phi_deg = np.degrees(phi_v[frame_idx, i])
        psi_deg = np.degrees(psi_v[frame_idx, i])
        rama_label = get_rama_label(phi_deg, psi_deg, df_rama)
        if len(rama_label) != 2:
            rama_label = "??"
        one_letter = AA_THREE_TO_ONE.get(rname, "X")
        base_str = f"{one_letter}{rama_label}"
        full_parts.append(base_str)
        full_parts_no_chi2.append(base_str)
        if 5 <= rnum <= 12:
            filtered_parts.append(base_str)
            filtered_parts_no_chi2.append(base_str)
        if rnum < 104:
            om_deg = get_omega_angle_for_residue(traj, frame_idx, rnum, om_i, om_v)
            chi1_deg = get_chi1_angle_for_residue(traj, frame_idx, rnum, chi1_i, chi1_v)
            chi2_deg = get_chi2_angle_for_residue(traj, frame_idx, rnum, chi2_i, chi2_v)
        else:
            om_deg = None
            chi1_deg = None
            chi2_deg = None
        if om_deg is not None:
            om_lbl = "1" if -90 <= om_deg <= 90 else "0"
        else:
            om_lbl = "X"
        if chi1_deg is not None:
            if rname.upper() in rotamer_config and "chi1" in rotamer_config[rname.upper()]:
                bvals = [float(x) for x in rotamer_config[rname.upper()]["chi1"]["boundaries"]]
                labs  = rotamer_config[rname.upper()]["chi1"]["labels"]
                debug_str = f"chi1 boundaries: {bvals}, labels: {labs}; chi1 value: {chi1_deg} -> "
                assigned = False
                for bb, bnd in enumerate(bvals):
                    debug_str += f"(if {chi1_deg} < {bnd}: "
                    if chi1_deg < bnd:
                        debug_str += f"True, label {labs[bb]}) "
                        chi1_lbl = str(labs[bb])
                        assigned = True
                        break
                    else:
                        debug_str += "False) "
                if not assigned:
                    debug_str += f"Fallback label {labs[-1]}"
                    chi1_lbl = str(labs[-1])
                if debug:
                    print(f"Residue {rnum} {rname}: chi1: normalized value = {chi1_deg}. {debug_str}", end="; ")
            else:
                chi1_lbl = "X"
                if debug:
                    print(f"Residue {rnum} {rname}: chi1: No config found; assigned 'X'.", end="; ")
        else:
            chi1_lbl = "X"
            if debug:
                print(f"Residue {rnum} {rname}: chi1: value is None; assigned 'X'.", end="; ")
        if chi2_deg is not None:
            if rname.upper() in rotamer_config and "chi2" in rotamer_config[rname.upper()]:
                bvals = [float(x) for x in rotamer_config[rname.upper()]["chi2"]["boundaries"]]
                labs  = rotamer_config[rname.upper()]["chi2"]["labels"]
                debug_str2 = f"chi2 boundaries: {bvals}, labels: {labs}; chi2 value: {chi2_deg} -> "
                assigned = False
                for bb, bnd in enumerate(bvals):
                    debug_str2 += f"(if {chi2_deg} < {bnd}: "
                    if chi2_deg < bnd:
                        debug_str2 += f"True, label {labs[bb]}) "
                        chi2_lbl = str(labs[bb])
                        assigned = True
                        break
                    else:
                        debug_str2 += "False) "
                if not assigned:
                    debug_str2 += f"Fallback label {labs[-1]}"
                    chi2_lbl = str(labs[-1])
                if debug:
                    print(f"Residue {rnum} {rname}: chi2: normalized value = {chi2_deg}. {debug_str2}", end="; ")
            else:
                chi2_lbl = "X"
                if debug:
                    print(f"Residue {rnum} {rname}: chi2: No config found; assigned 'X'.", end="; ")
        else:
            chi2_lbl = "X"
            if debug:
                print(f"Residue {rnum} {rname}: chi2: value is None; assigned 'X'.", end="; ")
        extra_with = f"{om_lbl}{chi1_lbl}{chi2_lbl}"
        extra_without = f"{om_lbl}{chi1_lbl}"
        full_parts[-1] += extra_with
        full_parts_no_chi2[-1] += extra_without
        if 5 <= rnum <= 12:
            filtered_parts[-1] += extra_with
            filtered_parts_no_chi2[-1] += extra_without
        if debug:
            print(f"key segment: {base_str + extra_with}")
    full_key = "".join(full_parts)
    full_key_no_chi2 = "".join(full_parts_no_chi2)
    filtered_key = "".join(filtered_parts) if filtered_parts else None
    filtered_key_no_chi2 = "".join(filtered_parts_no_chi2) if filtered_parts_no_chi2 else None
    if debug:
        print(f"DEBUG: Final conformation key for frame {frame_idx}: {full_key}")
    return (full_key, filtered_key, full_key_no_chi2, filtered_key_no_chi2)

# ----------------- PHI/PSI HISTOGRAM FUNCTIONS -----------------

def ensure_residue_hist(shifted_res_id):
    global PHI_PSI_HISTS
    if shifted_res_id not in PHI_PSI_HISTS:
        PHI_PSI_HISTS[shifted_res_id] = np.zeros((PHI_PSI_BINS, PHI_PSI_BINS), dtype=np.int64)

def update_phi_psi_histograms(traj):
    global PHI_PSI_HISTS
    phi_i, phi_v = md.compute_phi(traj)
    psi_i, psi_v = md.compute_psi(traj)
    for i in range(len(phi_i)):
        residue = traj.topology.atom(phi_i[i][1]).residue
        if residue.index < 1 or residue.index >= 16:
            continue
        shifted_res_id = residue.index - 1
        ensure_residue_hist(shifted_res_id)
    for i in range(len(psi_i)):
        residue = traj.topology.atom(psi_i[i][1]).residue
        if residue.index < 1 or residue.index >= 16:
            continue
        shifted_res_id = residue.index - 1
        ensure_residue_hist(shifted_res_id)
    n_frames = traj.n_frames
    for frame_idx in range(n_frames):
        psi_dict = {}
        for psi_idx in range(len(psi_i)):
            residue = traj.topology.atom(psi_i[psi_idx][1]).residue
            if residue.index < 1 or residue.index >= 16:
                continue
            shifted_res_id = residue.index - 1
            angle_deg = np.degrees(psi_v[frame_idx, psi_idx])
            psi_dict[shifted_res_id] = angle_deg
        for phi_idx in range(len(phi_i)):
            residue = traj.topology.atom(phi_i[phi_idx][1]).residue
            if residue.index < 1 or residue.index >= 16:
                continue
            shifted_res_id = residue.index - 1
            phi_deg = np.degrees(phi_v[frame_idx, phi_idx])
            if shifted_res_id not in psi_dict:
                continue
            psi_deg = psi_dict[shifted_res_id]
            phi_bin = int(phi_deg + 180) % PHI_PSI_BINS
            psi_bin = int(psi_deg + 180) % PHI_PSI_BINS
            PHI_PSI_HISTS[shifted_res_id][phi_bin, psi_bin] += 1

def save_phi_psi_histograms():
    global PHI_PSI_HISTS
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    for shifted_res_id, hist in PHI_PSI_HISTS.items():
        res_dir = os.path.join(OUTPUT_DIR, f"res_{shifted_res_id:02d}")
        os.makedirs(res_dir, exist_ok=True)
        out_npy = os.path.join(res_dir, f"res_{shifted_res_id:02d}_phi_psi_hist.npy")
        np.save(out_npy, hist)

def create_ramachandran_heatmaps(chunk_i):
    global PHI_PSI_HISTS
    for shifted_res_id, hist in PHI_PSI_HISTS.items():
        res_dir = os.path.join(OUTPUT_DIR, f"res_{shifted_res_id:02d}")
        os.makedirs(res_dir, exist_ok=True)
        plt.figure()
        plt.imshow(hist.T, origin='lower', extent=(-180, 180, -180, 180), aspect='auto')
        plt.colorbar(label="Counts")
        plt.xlabel("Phi (deg)")
        plt.ylabel("Psi (deg)")
        plt.title(f"Residue {shifted_res_id} Ramachandran at chunk {chunk_i}")
        out_png = os.path.join(res_dir, f"res_{shifted_res_id:02d}_rama_plot.png")
        plt.savefig(out_png, dpi=120)
        plt.close()

def snapshot_phi_psi_histograms(chunk_i):
    snap_dir = os.path.join(OUTPUT_DIR, "snapshots")
    os.makedirs(snap_dir, exist_ok=True)
    global PHI_PSI_HISTS
    for shifted_res_id in PHI_PSI_HISTS:
        src_dir = os.path.join(OUTPUT_DIR, f"res_{shifted_res_id:02d}")
        src_file = os.path.join(src_dir, f"res_{shifted_res_id:02d}_phi_psi_hist.npy")
        if os.path.exists(src_file):
            dst_file = os.path.join(snap_dir, f"hist_res_{shifted_res_id:02d}_chunk_{chunk_i}.npy")
            shutil.copy(src_file, dst_file)

# ----------------- HELPER: GET LAST COMPLETED CHUNK NUMBER -----------------

def get_last_completed_chunk():
    chunks = []
    base_files = glob.glob("step*.gro")
    if base_files:
        for f in base_files:
            m = re.search(r"step(\d+)\.gro", f)
            if m:
                chunks.append(int(m.group(1)))
        if chunks:
            return max(chunks), f"step{max(chunks)}"
    group_dirs = glob.glob(f"{GROUP_DIR_PREFIX}*")
    if group_dirs:
        groups = []
        for d in group_dirs:
            m = re.search(rf"{GROUP_DIR_PREFIX}(\d+)", d)
            if m:
                groups.append(int(m.group(1)))
        if groups:
            last_group = max(groups)
            last_chunk = last_group * 1000
            gro_files = glob.glob(os.path.join(f"{GROUP_DIR_PREFIX}{last_group}", "step*.gro"))
            if gro_files:
                nums = []
                for f in gro_files:
                    m = re.search(r"step(\d+)\.gro", os.path.basename(f))
                    if m:
                        nums.append(int(m.group(1)))
                if nums:
                    max_chunk = max(nums)
                    prev_prefix = os.path.join(f"{GROUP_DIR_PREFIX}{last_group}", f"step{max_chunk}")
                    return max_chunk, prev_prefix
    return 0, EQUI_PREFIX

# ----------------- MOVE & COMPRESS GROUP FILES -----------------

def move_group_files(group_number):
    group_start = (group_number - 1) * 1000 + 1
    group_end = group_number * 1000
    dest_folder = f"{GROUP_DIR_PREFIX}{group_number}"
    if not os.path.exists(dest_folder):
        os.makedirs(dest_folder)
    for chunk in range(group_start, group_end + 1):
        pattern = f"step{chunk}*"
        for fpath in glob.glob(pattern):
            basename = os.path.basename(fpath)
            if basename == "step5_production.mdp":
                continue
            prefix = f"step{chunk}"
            if len(basename) <= len(prefix) or basename[len(prefix)] not in {'.', '_'}:
                continue
            os.rename(fpath, os.path.join(dest_folder, basename))

def compress_group_folder(group_number):
    folder = f"{GROUP_DIR_PREFIX}{group_number}"
    if os.path.exists(folder):
        tar_path = folder + ".tar.gz"
        with tarfile.open(tar_path, "w:gz") as tar:
            tar.add(folder, arcname=os.path.basename(folder))
        print(f"Compressed {folder} into {tar_path}")
        # Remove the original uncompressed folder.
        shutil.rmtree(folder)
        print(f"Removed original folder {folder}")

# ----------------- SNAPSHOT MASTER NPY FILES -----------------

def snapshot_master_csvs(current_chunk: int):
    snapshot_dir = os.path.join(OUTPUT_DIR, "snapshots")
    if not os.path.exists(snapshot_dir):
        os.makedirs(snapshot_dir, exist_ok=True)
    if os.path.exists(MASTER_NPY):
        base = os.path.basename(MASTER_NPY).split('.')[0]
        dest_file = os.path.join(snapshot_dir, f"{base}_snapshot_{current_chunk}.npy")
        shutil.copy(MASTER_NPY, dest_file)
        print(f"Snapshot saved: {dest_file}")

# ----------------- ANALYZE CHUNK BG (ASYNCHRONOUS) -----------------

def analyze_chunk_bg(chunk_i: int, rotamer_dict):
    if chunk_i < EQUILIBRATION_CHUNKS:
        print(f"Chunk {chunk_i}: In equilibration phase (threshold: {EQUILIBRATION_CHUNKS}), skipping analysis.")
        return
    try:
        load_or_determine_global_minimum()
        
        step_prefix = f"step{chunk_i}"
        xtc_file = f"{step_prefix}.xtc"
        gro_file = f"{step_prefix}.gro"
        edr_file = f"{step_prefix}.edr"
        if not (os.path.exists(xtc_file) and os.path.exists(gro_file)):
            print(f"WARNING: Missing {xtc_file} or {gro_file}, skipping chunk {chunk_i}.")
            return

        traj = md.load_xtc(xtc_file, top=gro_file)
        (phi_i, phi_v, psi_i, psi_v,
         chi1_i, chi1_v, chi2_i, chi2_v,
         om_i, om_v) = compute_phi_psi_chi1_chi2_omega(traj)
        tE, pE = parse_potential(edr_file)
        global CONFORMATION_STATS, FILTERED_STATS, CONFORMATION_STATS_NO_CHI2, FILTERED_STATS_NO_CHI2, MASTER_HIST, MIN_ENERGY

        chunk_min_energy = None
        for fi in range(traj.n_frames):
            pot_val = nearest_potential(traj.time[fi], tE, pE)
            if chunk_min_energy is None or pot_val < chunk_min_energy:
                chunk_min_energy = pot_val
            if fi == 0:
                key_tuple = classify_conformation(traj, fi,
                                                  phi_i, phi_v, psi_i, psi_v,
                                                  chi1_i, chi1_v, chi2_i, chi2_v,
                                                  om_i, om_v, rotamer_dict, debug=True)
                print(f"DEBUG: First conformation key for chunk {chunk_i}: {key_tuple[0]}")
            else:
                key_tuple = classify_conformation(traj, fi,
                                                  phi_i, phi_v, psi_i, psi_v,
                                                  chi1_i, chi1_v, chi2_i, chi2_v,
                                                  om_i, om_v, rotamer_dict)
            reduced_val = (pot_val - MIN_ENERGY) / (kB * TEMPERATURE)
            b_factor = np.exp(-reduced_val)
            if DEBUG and np.isclose(b_factor, 0.0):
                print(f"DEBUG: Boltzmann factor for frame {fi} (key: {key_tuple[0]}) is zero. pot_val = {pot_val}, MIN_ENERGY = {MIN_ENERGY}, reduced = {reduced_val}, exponent = {-reduced_val}")
            oldc, old_W, old_WE = CONFORMATION_STATS.get(key_tuple[0], (0, 0.0, 0.0))
            CONFORMATION_STATS[key_tuple[0]] = (oldc + 1, old_W + b_factor, old_WE + reduced_val * b_factor)
            oldc2, old_W2, old_WE2 = CONFORMATION_STATS_NO_CHI2.get(key_tuple[2], (0, 0.0, 0.0))
            CONFORMATION_STATS_NO_CHI2[key_tuple[2]] = (oldc2 + 1, old_W2 + b_factor, old_WE2 + reduced_val * b_factor)
            if key_tuple[1] is not None:
                oldc_f, old_W_f, old_WE_f = FILTERED_STATS.get(key_tuple[1], (0, 0.0, 0.0))
                FILTERED_STATS[key_tuple[1]] = (oldc_f + 1, old_W_f + b_factor, old_WE_f + reduced_val * b_factor)
            if key_tuple[3] is not None:
                oldc_f2, old_W_f2, old_WE_f2 = FILTERED_STATS_NO_CHI2.get(key_tuple[3], (0, 0.0, 0.0))
                FILTERED_STATS_NO_CHI2[key_tuple[3]] = (oldc_f2 + 1, old_W_f2 + b_factor, old_WE_f2 + reduced_val * b_factor)
        if chunk_min_energy is not None:
            min_energy_fname = f"{step_prefix}_min_energy.txt"
            with open(min_energy_fname, "w") as f:
                f.write(f"{chunk_min_energy}")
            print(f"Chunk {chunk_i}: Minimum energy = {chunk_min_energy}")
        print(f"Chunk {chunk_i}: Processed {traj.n_frames} frames => updated stats for {len(CONFORMATION_STATS)} full keys, {len(CONFORMATION_STATS_NO_CHI2)} full keys (no chi2).")
        
        print(f"Chunk {chunk_i}: Retaining full trajectory file {xtc_file}.")
        if chunk_i > EQUILIBRATION_CHUNKS:
            hist_result = compute_sidechain_histogram(traj)
            if hist_result is not None:
                hist, edges = hist_result
                MASTER_HIST += hist
                with open(os.path.join(OUTPUT_DIR, "master_histogram.pkl"), "wb") as f:
                    pickle.dump(MASTER_HIST, f)
                print(f"Chunk {chunk_i}: Updated and saved master histogram.")
            else:
                print(f"Chunk {chunk_i}: Could not compute sidechain histogram (residues 5,9,12 missing).")
        
        if chunk_i >= EQUILIBRATION_CHUNKS:
            master_data = []
            for key, (cnt, W_tot, WE_tot) in CONFORMATION_STATS.items():
                master_data.append([key, cnt, W_tot, WE_tot])
            os.makedirs(OUTPUT_DIR, exist_ok=True)
            np.save(MASTER_NPY, np.array(master_data, dtype=object))
            if DEBUG:
                debug_master = np.load(MASTER_NPY, allow_pickle=True)
                print("DEBUG: MASTER_NPY contents (first 5 rows):", debug_master[:5])
            
            if os.path.exists(UNIQUE_KEYS_NPY):
                unique_keys_data = np.load(UNIQUE_KEYS_NPY, allow_pickle=True).tolist()
                prev_cum = unique_keys_data[-1].get("cumulative", 0) if unique_keys_data else 0
            else:
                unique_keys_data = []
                prev_cum = 0
            new_count = len(master_data)
            cumulative = prev_cum + new_count
            unique_keys_data.append({"chunk": chunk_i, "unique_count": new_count, "cumulative": cumulative})
            np.save(UNIQUE_KEYS_NPY, unique_keys_data)
            if DEBUG:
                debug_unique = np.load(UNIQUE_KEYS_NPY, allow_pickle=True).tolist()
                print("DEBUG: UNIQUE_KEYS_NPY contents:", debug_unique)
            plt.figure()
            unique_keys_data = np.load(UNIQUE_KEYS_NPY, allow_pickle=True).tolist()
            chunks_list = [entry["chunk"] for entry in unique_keys_data]
            cumulative_list = [entry["cumulative"] for entry in unique_keys_data]
            plt.plot(chunks_list, cumulative_list, marker='o')
            plt.xlabel("Chunk")
            plt.ylabel("Cumulative Unique Full Keys")
            plt.title("Full Keys vs Chunk Count")
            plt.savefig(UNIQUE_KEYS_PNG, dpi=120)
            plt.close()
            print(f"Chunk {chunk_i}: Wrote full key npy and plots.")
            
            if os.path.exists(UNIQUE_KEYS_NO_CHI2_NPY):
                unique_keys_nochi2_data = np.load(UNIQUE_KEYS_NO_CHI2_NPY, allow_pickle=True).tolist()
                prev_cum_nochi2 = unique_keys_nochi2_data[-1].get("cumulative", 0) if unique_keys_nochi2_data else 0
            else:
                unique_keys_nochi2_data = []
                prev_cum_nochi2 = 0
            new_count_nochi2 = len(CONFORMATION_STATS_NO_CHI2)
            cumulative_nochi2 = prev_cum_nochi2 + new_count_nochi2
            unique_keys_nochi2_data.append({"chunk": chunk_i, "unique_count": new_count_nochi2, "cumulative": cumulative_nochi2})
            np.save(UNIQUE_KEYS_NO_CHI2_NPY, unique_keys_nochi2_data)
            if DEBUG:
                debug_unique_nochi2 = np.load(UNIQUE_KEYS_NO_CHI2_NPY, allow_pickle=True).tolist()
                print("DEBUG: UNIQUE_KEYS_NO_CHI2 contents:", debug_unique_nochi2)
            plt.figure()
            unique_keys_nochi2_data = np.load(UNIQUE_KEYS_NO_CHI2_NPY, allow_pickle=True).tolist()
            chunks_list = [entry["chunk"] for entry in unique_keys_nochi2_data]
            cumulative_list = [entry["cumulative"] for entry in unique_keys_nochi2_data]
            plt.plot(chunks_list, cumulative_list, marker='o')
            plt.xlabel("Chunk")
            plt.ylabel("Cumulative Unique Full Keys (No Chi2)")
            plt.title("Full Keys (No Chi2) vs Chunk Count")
            plt.savefig(UNIQUE_KEYS_NO_CHI2_PNG, dpi=120)
            plt.close()
            print(f"Chunk {chunk_i}: Wrote full key no chi2 npy and plots.")
            
            if os.path.exists(UNIQUE_KEYS_FILTERED_NPY):
                unique_keys_filtered_data = np.load(UNIQUE_KEYS_FILTERED_NPY, allow_pickle=True).tolist()
                prev_cum_filtered = unique_keys_filtered_data[-1].get("cumulative", 0) if unique_keys_filtered_data else 0
            else:
                unique_keys_filtered_data = []
                prev_cum_filtered = 0
            new_count_filtered = len(FILTERED_STATS)
            cumulative_filtered = prev_cum_filtered + new_count_filtered
            unique_keys_filtered_data.append({"chunk": chunk_i, "unique_count": new_count_filtered, "cumulative": cumulative_filtered})
            np.save(UNIQUE_KEYS_FILTERED_NPY, unique_keys_filtered_data)
            if DEBUG:
                debug_unique_filtered = np.load(UNIQUE_KEYS_FILTERED_NPY, allow_pickle=True).tolist()
                print("DEBUG: UNIQUE_KEYS_FILTERED_NPY contents:", debug_unique_filtered)
            plt.figure()
            unique_keys_filtered_data = np.load(UNIQUE_KEYS_FILTERED_NPY, allow_pickle=True).tolist()
            chunks_filtered = [entry["chunk"] for entry in unique_keys_filtered_data]
            cumulative_filtered_list = [entry["cumulative"] for entry in unique_keys_filtered_data]
            plt.plot(chunks_filtered, cumulative_filtered_list, marker='o')
            plt.xlabel("Chunk")
            plt.ylabel("Cumulative Unique Filtered Keys")
            plt.title("Filtered Keys vs Chunk Count")
            plt.savefig(UNIQUE_KEYS_FILTERED_PNG, dpi=120)
            plt.close()
            print(f"Chunk {chunk_i}: Wrote filtered key npy and plots.")
            
            if os.path.exists(UNIQUE_KEYS_FILTERED_NO_CHI2_NPY):
                unique_keys_filtered_nochi2_data = np.load(UNIQUE_KEYS_FILTERED_NO_CHI2_NPY, allow_pickle=True).tolist()
                prev_cum_filtered_nochi2 = unique_keys_filtered_nochi2_data[-1].get("cumulative", 0) if unique_keys_filtered_nochi2_data else 0
            else:
                unique_keys_filtered_nochi2_data = []
                prev_cum_filtered_nochi2 = 0
            new_count_filtered_nochi2 = len(FILTERED_STATS_NO_CHI2)
            cumulative_filtered_nochi2 = prev_cum_filtered_nochi2 + new_count_filtered_nochi2
            unique_keys_filtered_nochi2_data.append({"chunk": chunk_i, "unique_count": new_count_filtered_nochi2, "cumulative": cumulative_filtered_nochi2})
            np.save(UNIQUE_KEYS_FILTERED_NO_CHI2_NPY, unique_keys_filtered_nochi2_data)
            if DEBUG:
                debug_unique_filtered_nochi2 = np.load(UNIQUE_KEYS_FILTERED_NO_CHI2_NPY, allow_pickle=True).tolist()
                print("DEBUG: UNIQUE_KEYS_FILTERED_NO_CHI2 contents:", debug_unique_filtered_nochi2)
            plt.figure()
            unique_keys_filtered_nochi2_data = np.load(UNIQUE_KEYS_FILTERED_NO_CHI2_NPY, allow_pickle=True).tolist()
            chunks_filtered = [entry["chunk"] for entry in unique_keys_filtered_nochi2_data]
            cumulative_filtered_nochi2_list = [entry["cumulative"] for entry in unique_keys_filtered_nochi2_data]
            plt.plot(chunks_filtered, cumulative_filtered_nochi2_list, marker='o')
            plt.xlabel("Chunk")
            plt.ylabel("Cumulative Unique Filtered Keys (No Chi2)")
            plt.title("Filtered Keys (No Chi2) vs Chunk Count")
            plt.savefig(UNIQUE_KEYS_FILTERED_NO_CHI2_PNG, dpi=120)
            plt.close()
            print(f"Chunk {chunk_i}: Wrote filtered key no chi2 npy and plots.")
        else:
            print(f"Chunk {chunk_i}: CSV write skipped (chunk < {EQUILIBRATION_CHUNKS}).")
        
        update_phi_psi_histograms(traj)
        save_phi_psi_histograms()
        if chunk_i >= EQUILIBRATION_CHUNKS + 50 and (chunk_i - 50) % 100 == 0:
            print(f"Chunk {chunk_i}: Generating Ramachandran heatmaps...")
            create_ramachandran_heatmaps(chunk_i)
        if chunk_i % 100 == 0:
            print(f"Chunk {chunk_i}: Saving snapshot of φ/ψ histograms...")
            snapshot_phi_psi_histograms(chunk_i)
        
    except Exception as e:
        print(f"ERROR analyzing chunk {chunk_i} in background: {e}")

##############################################################################
#                                  MAIN                                      #
##############################################################################

def run_chunk(i, prev_prefix):
    grompp_and_mdrun(i, prev_prefix)

def get_last_completed_chunk():
    chunks = []
    base_files = glob.glob("step*.gro")
    if base_files:
        for f in base_files:
            m = re.search(r"step(\d+)\.gro", f)
            if m:
                chunks.append(int(m.group(1)))
        if chunks:
            return max(chunks), f"step{max(chunks)}"
    group_dirs = glob.glob(f"{GROUP_DIR_PREFIX}*")
    if group_dirs:
        groups = []
        for d in group_dirs:
            m = re.search(rf"{GROUP_DIR_PREFIX}(\d+)", d)
            if m:
                groups.append(int(m.group(1)))
        if groups:
            last_group = max(groups)
            last_chunk = last_group * 1000
            gro_files = glob.glob(os.path.join(f"{GROUP_DIR_PREFIX}{last_group}", "step*.gro"))
            if gro_files:
                nums = []
                for f in gro_files:
                    m = re.search(r"step(\d+)\.gro", os.path.basename(f))
                    if m:
                        nums.append(int(m.group(1)))
                if nums:
                    max_chunk = max(nums)
                    prev_prefix = os.path.join(f"{GROUP_DIR_PREFIX}{last_group}", f"step{max_chunk}")
                    return max_chunk, prev_prefix
    return 0, EQUI_PREFIX

def move_group_files(group_number):
    group_start = (group_number - 1) * 1000 + 1
    group_end = group_number * 1000
    dest_folder = f"{GROUP_DIR_PREFIX}{group_number}"
    if not os.path.exists(dest_folder):
        os.makedirs(dest_folder)
    for chunk in range(group_start, group_end + 1):
        pattern = f"step{chunk}.*"
        for fpath in glob.glob(pattern):
            basename = os.path.basename(fpath)
            if basename == "step5_production.mdp":
                continue
            prefix = f"step{chunk}"
            if len(basename) <= len(prefix) or basename[len(prefix)] not in {'.', '_'}:
                continue
            os.rename(fpath, os.path.join(dest_folder, basename))

##############################################################################
#         MAIN LOOP AND ON-THE-FLY COMPRESSION (1000N+5)                     #
##############################################################################
def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    debug_residues_info()
    debug_rotamer_config()
    load_existing_histograms()
    if os.path.exists(GLOBAL_MIN_ENERGY_FILE):
        load_global_min_energy()
    # Load rotamer configuration.
    rotamer_config = {}
    if os.path.exists(ROTAMER_CONFIG_FILE):
        try:
            with open(ROTAMER_CONFIG_FILE, "r") as f:
                rotamer_config = json.load(f)
        except Exception as e:
            print("Failed to load rotamer config in main:", e)
    last_chunk, _ = get_last_completed_chunk()
    current_group = ((last_chunk - 1) // 1000) + 1 if last_chunk > 0 else 0
    all_files = glob.glob("step*.*")
    group_numbers = set()
    for f in all_files:
        m = re.search(r"step(\d+)", f)
        if m:
            chunk_num = int(m.group(1))
            group_num = ((chunk_num - 1) // 1000) + 1
            group_numbers.add(group_num)
    for group in sorted(group_numbers):
        if current_group > 0 and group < current_group:
            print(f"Startup: Moving finished group {group}.")
            move_group_files(group)
            compress_group_folder(group)
    start_chunk = last_chunk + 1
    if start_chunk > N_CHUNKS:
        print("All chunks already completed. Exiting.")
        return
    prev_prefix = EQUI_PREFIX if start_chunk == 1 else f"step{last_chunk}"
    print(f"Resuming from chunk {start_chunk} (previous completed chunk: {last_chunk}).")
    print(f"Starting main() with N_CHUNKS={N_CHUNKS}")
    group_futures = {}
    analysis_futures = []
    with ThreadPoolExecutor() as executor:
        for i in range(start_chunk, N_CHUNKS + 1):
            print(f"\n=== Now running chunk {i} ===")
            t0 = time.time()
            print(f"Running grompp_and_mdrun for chunk {i} with prev_prefix={prev_prefix}...")
            run_chunk(i, prev_prefix)
            t1 = time.time()
            sec = t1 - t0
            cpd = 86400.0 / sec
            print(f"Chunk {i} gromacs step finished in {sec:.2f}s => {cpd:.2f} chunks/day")
            fut = executor.submit(analyze_chunk_bg, i, rotamer_config)
            analysis_futures.append(fut)
            if i > EQUILIBRATION_CHUNKS and (i - 1) % 1000 == 0:
                group_number = (i - 1) // 1000
                print(f"Chunk {i}: Group boundary reached. Waiting for analysis of group {group_number} to finish...")
                wait(group_futures.get(group_number, []))
                print(f"Chunk {i}: Moving group {group_number} output files.")
                move_group_files(group_number)
                snapshot_chunk = i - 1
                snapshot_master_csvs(snapshot_chunk)
            # ON-THE-FLY COMPRESSION: every 1000N + 5 where N > 0.
            if i > 5 and (i - 5) % 1000 == 0:
                group_to_compress = (i - 5) // 1000
                print(f"Chunk {i}: Compressing group {group_to_compress} output files.")
                compress_group_folder(group_to_compress)
            group_num = i // 1000
            group_futures.setdefault(group_num, []).append(fut)
            prev_prefix = f"step{i}"
        for future in analysis_futures:
            future.result()
    print("All chunks + analyses completed. Exiting now.")

if __name__ == "__main__":
    main()

