import re
import pandas as pd

def parse_gro_atoms(gro_file):
    atoms = {}
    with open(gro_file, 'r') as f:
        lines = f.readlines()[2:-1]
        for line in lines:
            atom_num = int(line[15:20])
            atoms[atom_num] = {
                'res_num': int(line[:5]),
                'res_name': line[5:10].strip(),
                'atom_name': line[10:15].strip()
            }
    return atoms

def parse_restraint_file(itp_file, restraint_type, atoms):
    restraints = []
    with open(itp_file, 'r') as f:
        for line in f:
            if re.match(r'^\s*\d+', line):
                parts = line.strip().split()
                atom_indices = [int(p) for p in parts[:4] if p.isdigit()]
                atom_details = []
                for atom_idx in atom_indices:
                    atom_info = atoms.get(atom_idx, {'res_num':'N/A','res_name':'Not Found','atom_name':'N/A'})
                    atom_details.append(f"{atom_info['res_name']}-{atom_info['res_num']}-{atom_info['atom_name']}({atom_idx})")
                restraints.append({
                    'Restraint Type': restraint_type,
                    'Atoms Restrained': ', '.join(atom_details),
                    'Original Line': line.strip()
                })
    return restraints

def main():
    gro_file = 'step3_input.gro'
    distance_itp = 'Restraints_V2/distance_restraints.itp'
    dihedral_itp = 'Restraints_V2/dihedral_restraints.itp'

    atoms = parse_gro_atoms(gro_file)

    # Parse distance restraints
    distance_restraints = parse_restraint_file(distance_itp, 'Distance', atoms)

    # Parse dihedral restraints
    dihedral_restraints = parse_restraint_file(dihedral_itp, 'Dihedral', atoms)

    # Combine into one DataFrame
    df = pd.DataFrame(distance_restraints + dihedral_restraints)

    # Save results to CSV for clear viewing
    df.to_csv('restraint_analysis.csv', index=False)

    print("Analysis complete. Results saved in 'restraint_analysis.csv'.")

if __name__ == '__main__':
    main()

