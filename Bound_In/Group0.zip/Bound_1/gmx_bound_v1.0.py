#!/usr/bin/env python3
"""
gmx_bound_v1.0.py

Bound state simulation script for a two-chain system.
This version assumes the topology file is named "topol.top" (with restraints added manually).
All residue-based selections are applied using the global residue indices:
  - FULL analysis: residues 91–105
  - SUBSET analysis: residues 95–102
  - COM analysis: residues 95, 99, and 102

The script processes simulation chunks using GROMACS, computes dihedral angles via MDTraj,
classifies conformations (using rotamer config and Ramachandran labeling), computes Boltzmann-weighted statistics,
and computes the center-of-mass (COM) for selected residues.
It also handles file grouping and asynchronous analysis.
"""

import os
import sys
import time
import json
import subprocess
import re
import glob
import numpy as np
import pandas as pd
import mdtraj as md
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from concurrent.futures import ThreadPoolExecutor

##############################################################################
#                                USER CONFIG                                 #
##############################################################################

DEBUG = False  # Enable detailed debug prints

N_CHUNKS = 100000   # Total simulation chunks to process
EQUILIBRATION_END_CHUNK = 1000  # Chunks below this are in equilibration.
MDP_FILE = "step5_production.mdp"
TOPOL    = "topol.top"   # Topology file is topol.top (restraints already added manually)
INDEX    = "index.ndx"
EQUI_PREFIX = "step4.1_equilibration"

# Rotamer configuration and Ramachandran CSV directory
ROTAMER_CONFIG_FILE = "data/rotamer_config_trinary.json"
RAMA_CSV_DIR        = "data/Ramachandran"
OUTPUT_DIR          = "analysis_output_bound"

# Output files for storing conformation statistics (as npy files)
MASTER_NPY_FULL           = os.path.join(OUTPUT_DIR, "master_conformations_full.npy")
MASTER_NPY_NO_CHI2        = os.path.join(OUTPUT_DIR, "master_conformations_no_chi2.npy")
MASTER_NPY_SUBSET         = os.path.join(OUTPUT_DIR, "master_conformations_subset.npy")
MASTER_NPY_SUBSET_NO_CHI2 = os.path.join(OUTPUT_DIR, "master_conformations_subset_no_chi2.npy")

# Unique keys cumulative data files (saved as npy)
UNIQUE_KEYS_NPY_FULL           = os.path.join(OUTPUT_DIR, "unique_keys_by_chunk_full.npy")
UNIQUE_KEYS_NPY_NO_CHI2        = os.path.join(OUTPUT_DIR, "unique_keys_by_chunk_no_chi2.npy")
UNIQUE_KEYS_NPY_SUBSET         = os.path.join(OUTPUT_DIR, "unique_keys_by_chunk_subset.npy")
UNIQUE_KEYS_NPY_SUBSET_NO_CHI2 = os.path.join(OUTPUT_DIR, "unique_keys_by_chunk_subset_no_chi2.npy")

# COM analysis output file
COM_NPY_FILE = os.path.join(OUTPUT_DIR, "com_analysis.npy")

# Global dictionaries for conformation statistics
CONFORMATION_STATS_FULL           = {}
CONFORMATION_STATS_NO_CHI2        = {}
CONFORMATION_STATS_SUBSET         = {}
CONFORMATION_STATS_SUBSET_NO_CHI2 = {}

# Cumulative unique-key dictionaries.
if os.path.exists(UNIQUE_KEYS_NPY_FULL):
    unique_full = np.load(UNIQUE_KEYS_NPY_FULL, allow_pickle=True).item()
else:
    unique_full = {}
if os.path.exists(UNIQUE_KEYS_NPY_NO_CHI2):
    unique_no_chi2 = np.load(UNIQUE_KEYS_NPY_NO_CHI2, allow_pickle=True).item()
else:
    unique_no_chi2 = {}
if os.path.exists(UNIQUE_KEYS_NPY_SUBSET):
    unique_subset = np.load(UNIQUE_KEYS_NPY_SUBSET, allow_pickle=True).item()
else:
    unique_subset = {}
if os.path.exists(UNIQUE_KEYS_NPY_SUBSET_NO_CHI2):
    unique_subset_no_chi2 = np.load(UNIQUE_KEYS_NPY_SUBSET_NO_CHI2, allow_pickle=True).item()
else:
    unique_subset_no_chi2 = {}

# Dictionary to store COM values per chunk.
COM_VALUES = {}

# Filename for storing the lowest potential energy during equilibration.
LOWEST_ENERGY_FILENAME = os.path.join(OUTPUT_DIR, "lowest_energy.txt")

# Boltzmann parameters.
BOLTZMANN_TEMPERATURE = 300.0      # Kelvin
BOLTZMANN_CONSTANT = 0.0019872041  # kcal/(mol*K)
BETA = 1.0 / (BOLTZMANN_CONSTANT * BOLTZMANN_TEMPERATURE)

# Prefix for grouping files.
GROUP_DIR_PREFIX = "group_"

AA_THREE_TO_ONE = {
    "ALA": "A", "ARG": "R", "ASN": "N", "ASP": "D", "CYS": "C",
    "GLN": "Q", "GLU": "E", "GLY": "G", "HIS": "H", "ILE": "I",
    "LEU": "L", "LYS": "K", "MET": "M", "PHE": "F", "PRO": "P",
    "SER": "S", "THR": "T", "TRP": "W", "TYR": "Y", "VAL": "V"
}

# Analysis residue selections (global residue numbers)
FULL_ANALYSIS_RESIDUES    = {91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105}
SUBSET_ANALYSIS_RESIDUES  = {95, 96, 97, 98, 99, 100, 101, 102}
COM_ANALYSIS_RESIDUES     = {95, 99, 102}

##############################################################################
#                              UTILITY FUNCTIONS                             #
##############################################################################
def safe_list(x):
    try:
        return list(x)
    except TypeError:
        return x

def startup_debug_print(rotamer_config):
    gro_file = EQUI_PREFIX + ".gro"
    if not os.path.exists(gro_file):
        print(f"DEBUG: Equilibration GRO file {gro_file} not found; cannot print residue info.")
        return
    try:
        traj = md.load(gro_file)
    except Exception as e:
        print(f"DEBUG: Error loading GRO file: {e}")
        return
    # Determine the first analysis residue number.
    analysis_start = min(FULL_ANALYSIS_RESIDUES)
    print("DEBUG: Residues in the analysis window (FULL_ANALYSIS_RESIDUES):")
    for res in list(traj.topology.residues):
        if res.index not in FULL_ANALYSIS_RESIDUES:
            continue
        rnum = res.index
        rname = res.name
        csv_index = rnum - analysis_start   # Shift so first analysis residue is index 0
        rama_csv = f"rama_{csv_index:02d}{rname}.csv"
        print(f"Residue {rnum} ({rname}): Expected Rama CSV = {rama_csv}")
        if rname in rotamer_config:
            chi1_boundaries = safe_list(rotamer_config[rname].get("chi1", {}).get("boundaries", []))
            chi2_boundaries = safe_list(rotamer_config[rname].get("chi2", {}).get("boundaries", []))
            print(f"   chi1 boundaries: {chi1_boundaries if chi1_boundaries else 'None'}")
            print(f"   chi2 boundaries: {chi2_boundaries if chi2_boundaries else 'None'}")
        else:
            print("   No rotamer config available for this residue.")

##############################################################################
#                       DIHEDRAL ANGLE COMPUTATION                           #
##############################################################################
def compute_phi_psi_chi1chi2_omega(traj):
    phi_indices, phi = md.compute_phi(traj)
    psi_indices, psi = md.compute_psi(traj)
    if DEBUG:
        try:
            print("DEBUG: phi_indices type:", type(phi_indices), "shape:", np.array(phi_indices).shape)
        except Exception as e:
            print("DEBUG: Unable to print phi_indices shape:", e)
        try:
            print("DEBUG: phi angles shape:", phi.shape)
        except Exception as e:
            print("DEBUG: Unable to print phi angles shape:", e)
        try:
            print("DEBUG: psi_indices type:", type(psi_indices), "shape:", np.array(psi_indices).shape)
        except Exception as e:
            print("DEBUG: Unable to print psi_indices shape:", e)
        try:
            print("DEBUG: psi angles shape:", psi.shape)
        except Exception as e:
            print("DEBUG: Unable to print psi angles shape:", e)
    try:
        chi1_indices, chi1 = md.compute_chi1(traj)
    except Exception as e:
        if DEBUG:
            print("WARNING: md.compute_chi1 failed, setting chi1 angles to zeros.", e)
        chi1 = np.zeros((traj.n_frames, len(traj.topology.residues)))
        chi1_indices = None
    try:
        chi2_indices, chi2 = md.compute_chi2(traj)
    except Exception as e:
        if DEBUG:
            print("WARNING: md.compute_chi2 failed, setting chi2 angles to zeros.", e)
        chi2 = np.zeros((traj.n_frames, len(traj.topology.residues)))
        chi2_indices = None
    try:
        omega_indices, omega = md.compute_omega(traj)
    except Exception as e:
        if DEBUG:
            print("WARNING: md.compute_omega failed, setting omega angles to zeros.", e)
        omega = np.zeros((traj.n_frames, len(traj.topology.residues)))
        omega_indices = None
    return phi_indices, phi, psi_indices, psi, chi1_indices, chi1, chi2_indices, chi2, omega_indices, omega

##############################################################################
#                         GROMACS RUN FUNCTIONS                              #
##############################################################################
def run_command(cmd: str):
    p = subprocess.run(cmd, shell=True, text=True, capture_output=True)
    if p.returncode != 0:
        print(f"ERROR:\n{p.stderr}")
        sys.exit(1)

def grompp_and_mdrun(chunk_i, prev_prefix):
    step_prefix = f"step{chunk_i}"
    gro_in = f"{prev_prefix}.gro"
    cpt_in = f"{prev_prefix}.cpt"
    grompp_cmd = f"gmx grompp -f {MDP_FILE} -c {gro_in} -p {TOPOL} -n {INDEX} -o {step_prefix}.tpr"
    if os.path.exists(cpt_in):
        grompp_cmd += f" -t {cpt_in}"
    run_command(grompp_cmd)
    mdrun_cmd = f"gmx mdrun -s {step_prefix}.tpr -deffnm {step_prefix}"
    run_command(mdrun_cmd)

##############################################################################
#                          ENERGY PARSING FUNCTIONS                          #
##############################################################################
def parse_potential(edr_file: str):
    if not os.path.exists(edr_file):
        return np.array([]), np.array([])
    tmp_xvg = "temp_energy.xvg"
    cmd = f'echo Potential | gmx energy -f {edr_file} -o {tmp_xvg}'
    p = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if p.returncode != 0:
        return np.array([]), np.array([])
    times, pots = [], []
    with open(tmp_xvg, "r") as f:
        for line in f:
            if line.startswith(("#", "@")):
                continue
            cols = line.split()
            if len(cols) >= 2:
                times.append(float(cols[0]))
                pots.append(float(cols[1]))
    if os.path.exists(tmp_xvg):
        os.remove(tmp_xvg)
    return np.array(times), np.array(pots)

def nearest_potential(t_ps, timesE, potsE):
    if len(timesE) == 0:
        return 0.0
    idx = np.argmin(np.abs(timesE - t_ps))
    return potsE[idx]

##############################################################################
#                           RAMA CSV HELPER FUNCTIONS                         #
##############################################################################
def load_rama_csv(res_name, csv_res_num):
    csvfile = f"rama_{csv_res_num:02d}{res_name}.csv"
    fullpath = os.path.join(RAMA_CSV_DIR, csvfile)
    if not os.path.exists(fullpath):
        if DEBUG:
            print(f"DEBUG: File {fullpath} not found.")
        return None
    return pd.read_csv(fullpath)

def get_rama_label(phi_deg, psi_deg, df):
    if DEBUG:
        print(f"DEBUG: get_rama_label called with phi={phi_deg:.2f} psi={psi_deg:.2f}")
        print(f"DEBUG: Rama CSV DataFrame shape: {df.shape if df is not None else 'None'}")
    if df is None:
        if DEBUG:
            print("DEBUG: DataFrame is None.")
        return "??"
    try:
        distances = np.sqrt((df['phi'] - phi_deg)**2 + (df['psi'] - psi_deg)**2)
        idx_min = distances.idxmin()
        label = str(df.loc[idx_min, 'label'])
        if len(label) == 1:
            label = '0' + label
        return label[:2]
    except Exception as e:
        if DEBUG:
            print(f"DEBUG: Error in get_rama_label with phi_deg={phi_deg}, psi_deg={psi_deg}, df shape={df.shape if df is not None else 'None'}, error: {e}")
        return "??"

##############################################################################
#                    OMEGA & CHI RESIDUE RETRIEVAL FUNCTIONS                 #
##############################################################################
def find_omega_index_for_residue(res_i, om_i, topology):
    next_res = res_i + 1
    for idx, (a1, a2, a3, a4) in enumerate(om_i):
        rset = {topology.atom(a1).residue.index,
                topology.atom(a2).residue.index,
                topology.atom(a3).residue.index,
                topology.atom(a4).residue.index}
        if (res_i in rset) and (next_res in rset):
            return idx
    return None

def get_omega_angle_for_residue(traj, frame_idx, res_i, om_i, om_v):
    row_idx = find_omega_index_for_residue(res_i, om_i, traj.topology)
    if row_idx is None:
        return None
    try:
        angle = np.degrees(om_v[frame_idx, row_idx])
    except IndexError:
        return None
    return angle

def find_chi1_index_for_residue(res_i, chi1_i, topology):
    for idx, (a1, a2, a3, a4) in enumerate(chi1_i):
        rset = {topology.atom(a1).residue.index,
                topology.atom(a2).residue.index,
                topology.atom(a3).residue.index,
                topology.atom(a4).residue.index}
        if len(rset) == 1 and (res_i in rset):
            return idx
    return None

def get_chi1_angle_for_residue(traj, frame_idx, res_i, chi1_i, chi1_v):
    row_idx = find_chi1_index_for_residue(res_i, chi1_i, traj.topology)
    if row_idx is None:
        return None
    try:
        angle = np.degrees(chi1_v[frame_idx, row_idx])
    except IndexError:
        return None
    return angle

def find_chi2_index_for_residue(res_i, chi2_i, topology):
    for idx, (a1, a2, a3, a4) in enumerate(chi2_i):
        rset = {topology.atom(a1).residue.index,
                topology.atom(a2).residue.index,
                topology.atom(a3).residue.index,
                topology.atom(a4).residue.index}
        if len(rset) == 1 and (res_i in rset):
            return idx
    return None

def get_chi2_angle_for_residue(traj, frame_idx, res_i, chi2_i, chi2_v):
    row_idx = find_chi2_index_for_residue(res_i, chi2_i, traj.topology)
    if row_idx is None:
        return None
    try:
        angle = np.degrees(chi2_v[frame_idx, row_idx])
    except IndexError:
        return None
    return angle

##############################################################################
#                        CENTER-OF-MASS (COM) CALCULATION                    #
##############################################################################
def compute_com_for_frame(traj, frame_idx, com_residue_set):
    """
    Computes the center of mass for atoms in residues whose global residue index
    is in com_residue_set.
    """
    mass_dict = {"H": 1.008, "C": 12.011, "N": 14.007, "O": 15.999, "S": 32.06, "P": 30.974}
    atom_indices = []
    masses = []
    for atom in traj.topology.atoms:
        if atom.residue.index in com_residue_set:
            atom_indices.append(atom.index)
            element = atom.element.symbol if atom.element is not None else "C"
            masses.append(mass_dict.get(element, 12.011))
    if not atom_indices:
        return None
    coords = traj.xyz[frame_idx, atom_indices, :]  # shape: (n_atoms, 3)
    masses = np.array(masses)
    com = np.sum(coords * masses[:, None], axis=0) / masses.sum()
    return com

##############################################################################
#                        CLASSIFY CONFORMATION FUNCTION                      #
##############################################################################
def classify_conformation(traj, frame_idx,
                          phi_i, phi_v, psi_i, psi_v,
                          chi1_i, chi1_v, chi2_i, chi2_v,
                          om_i, om_v,
                          rotamer_config):
    full_keys = []
    full_keys_no_chi2 = []
    subset_keys = []
    subset_keys_no_chi2 = []
    analysis_start = min(FULL_ANALYSIS_RESIDUES)
    for i, indices in enumerate(phi_i):
        if len(indices) != 4:
            if DEBUG:
                print(f"Skipping phi index entry at position {i} with length {len(indices)} (expected 4)")
            continue
        a1, a2, a3, a4 = indices
        residue = traj.topology.atom(a2).residue
        rnum = residue.index
        # Process only residues in the analysis window.
        if rnum not in FULL_ANALYSIS_RESIDUES:
            continue
        rname = residue.name
        # Compute a zero-based csv index relative to the beginning of the analysis window.
        csv_index = rnum - analysis_start
        df_rama = load_rama_csv(rname, csv_index)
        phi_deg = np.degrees(phi_v[frame_idx, i])
        psi_deg = np.degrees(psi_v[frame_idx, i])
        rama_label = get_rama_label(phi_deg, psi_deg, df_rama)
        if len(rama_label) != 2:
            rama_label = "??"
        one_letter = AA_THREE_TO_ONE.get(rname, "X")
        base_key = f"{one_letter}{rama_label}"
        if rnum < 104:
            om_deg = get_omega_angle_for_residue(traj, frame_idx, rnum, om_i, om_v)
            ch1_deg = get_chi1_angle_for_residue(traj, frame_idx, rnum, chi1_i, chi1_v)
            ch2_deg = get_chi2_angle_for_residue(traj, frame_idx, rnum, chi2_i, chi2_v)
        else:
            om_deg = None
            ch1_deg = None
            ch2_deg = None
        om_lbl = "1" if (om_deg is not None and -90 <= om_deg <= 90) else ("0" if om_deg is not None else "X")
        if ch1_deg is not None:
            if rname in rotamer_config and "chi1" in rotamer_config[rname]:
                bvals = rotamer_config[rname]["chi1"]["boundaries"]
                labs  = rotamer_config[rname]["chi1"]["labels"]
                assigned = False
                for bb, bnd in enumerate(bvals):
                    if ch1_deg < bnd:
                        try:
                            ch1_lbl = str(labs[bb])
                        except IndexError as e:
                            if DEBUG:
                                print(f"DEBUG: IndexError for chi1: residue {rname} (rnum={rnum}), boundary index={bb}, labs={labs}")
                            ch1_lbl = "X"
                        assigned = True
                        break
                if not assigned:
                    try:
                        ch1_lbl = str(labs[-1])
                    except IndexError as e:
                        if DEBUG:
                            print(f"DEBUG: IndexError for chi1 last label: residue {rname}, labs={labs}")
                        ch1_lbl = "X"
            else:
                ch1_lbl = "X"
        else:
            ch1_lbl = "X"
        if ch2_deg is not None:
            if rname in rotamer_config and "chi2" in rotamer_config[rname]:
                bvals = rotamer_config[rname]["chi2"]["boundaries"]
                labs  = rotamer_config[rname]["chi2"]["labels"]
                assigned = False
                for bb, bnd in enumerate(bvals):
                    if ch2_deg < bnd:
                        try:
                            ch2_lbl = str(labs[bb])
                        except IndexError as e:
                            if DEBUG:
                                print(f"DEBUG: IndexError for chi2: residue {rname} (rnum={rnum}), boundary index={bb}, labs={labs}")
                            ch2_lbl = "X"
                        assigned = True
                        break
                if not assigned:
                    try:
                        ch2_lbl = str(labs[-1])
                    except IndexError as e:
                        if DEBUG:
                            print(f"DEBUG: IndexError for chi2 last label: residue {rname}, labs={labs}")
                        ch2_lbl = "X"
            else:
                ch2_lbl = "X"
        else:
            ch2_lbl = "X"
        res_full = f"{base_key}{om_lbl}{ch1_lbl}{ch2_lbl}"
        res_no_chi2 = f"{base_key}{om_lbl}{ch1_lbl}X"
        full_keys.append(res_full)
        full_keys_no_chi2.append(res_no_chi2)
        if rnum in SUBSET_ANALYSIS_RESIDUES:
            subset_keys.append(res_full)
            subset_keys_no_chi2.append(res_no_chi2)
    full_key_str = "".join(full_keys)
    full_key_no_chi2_str = "".join(full_keys_no_chi2)
    subset_key_str = "".join(subset_keys)
    subset_key_no_chi2_str = "".join(subset_keys_no_chi2)
    return (full_key_str, full_key_no_chi2_str, subset_key_str, subset_key_no_chi2_str)

##############################################################################
#           GET LAST COMPLETED CHUNK NUMBER (BASE DIRECTORY ONLY)            #
##############################################################################
def get_last_completed_chunk():
    chunks = []
    base_files = glob.glob("step*.gro")
    if base_files:
        for f in base_files:
            m = re.search(r"step(\d+)\.gro", f)
            if m:
                chunks.append(int(m.group(1)))
        if chunks:
            return max(chunks), f"step{max(chunks)}"
    group_dirs = glob.glob(f"{GROUP_DIR_PREFIX}*")
    if group_dirs:
        groups = []
        for d in group_dirs:
            m = re.search(rf"{GROUP_DIR_PREFIX}(\d+)", d)
            if m:
                groups.append(int(m.group(1)))
        if groups:
            last_group = max(groups)
            last_chunk = last_group * 1000
            gro_files = glob.glob(os.path.join(f"{GROUP_DIR_PREFIX}{last_group}", "step*.gro"))
            if gro_files:
                nums = []
                for f in gro_files:
                    m = re.search(r"step(\d+)\.gro", os.path.basename(f))
                    if m:
                        nums.append(int(m.group(1)))
                if nums:
                    max_chunk = max(nums)
                    prev_prefix = os.path.join(f"{GROUP_DIR_PREFIX}{last_group}", f"step{max_chunk}")
                    return max_chunk, prev_prefix
    return 0, EQUI_PREFIX

##############################################################################
#              MOVE AND ZIP GROUP FILES (FOR FILE MANAGEMENT)                #
##############################################################################
def move_group_files(group_number):
    group_start = (group_number - 1) * 1000 + 1
    group_end = group_number * 1000
    dest_folder = f"{GROUP_DIR_PREFIX}{group_number}"
    if not os.path.exists(dest_folder):
        os.makedirs(dest_folder)
    for chunk in range(group_start, group_end + 1):
        pattern = f"step{chunk}.*"
        for fpath in glob.glob(pattern):
            basename = os.path.basename(fpath)
            if "step4.0_minimization" in basename or "step4.1_equilibration" in basename or "step3_input" in basename:
                continue
            prefix = f"step{chunk}"
            if not basename[len(prefix):].startswith('.'):
                continue
            os.rename(fpath, os.path.join(dest_folder, basename))
    print(f"Group {group_number}: Files moved into folder {dest_folder}.")

def zip_group_files(group_number):
    dest_folder = f"{GROUP_DIR_PREFIX}{group_number}"
    zip_filename = dest_folder + ".zip"
    import zipfile, shutil
    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(dest_folder):
            for file in files:
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, start=dest_folder)
                zipf.write(file_path, arcname)
    shutil.rmtree(dest_folder)
    print(f"Group {group_number}: Folder zipped to {zip_filename} and original folder removed.")

##############################################################################
#              ANALYZE CHUNK IN BACKGROUND FUNCTION                        #
##############################################################################
def analyze_chunk_bg(chunk_i: int, rotamer_dict):
    if chunk_i < EQUILIBRATION_END_CHUNK:
        if DEBUG:
            print(f"Chunk {chunk_i}: In equilibration phase; updating lowest energy.")
        step_prefix = f"step{chunk_i}"
        xtc_file = f"{step_prefix}.xtc"
        gro_file = f"{step_prefix}.gro"
        edr_file = f"{step_prefix}.edr"
        if not (os.path.exists(xtc_file) and os.path.exists(gro_file)):
            print(f"WARNING: Missing {xtc_file} or {gro_file}; skipping lowest energy update for chunk {chunk_i}.")
            return
        traj = md.load_xtc(xtc_file, top=gro_file)
        tE, pE = parse_potential(edr_file)
        current_lowest = np.inf
        for E in pE:
            if E < current_lowest:
                current_lowest = E
        if os.path.exists(LOWEST_ENERGY_FILENAME):
            with open(LOWEST_ENERGY_FILENAME, "r") as f:
                stored_lowest = float(f.read().strip())
        else:
            stored_lowest = np.inf
        new_lowest = min(stored_lowest, current_lowest)
        with open(LOWEST_ENERGY_FILENAME, "w") as f:
            f.write(f"{new_lowest:.6f}")
        if DEBUG:
            print(f"Chunk {chunk_i}: Updated lowest energy to {new_lowest:.6f}")
        return

    try:
        step_prefix = f"step{chunk_i}"
        xtc_file = f"{step_prefix}.xtc"
        gro_file = f"{step_prefix}.gro"
        edr_file = f"{step_prefix}.edr"
        if not (os.path.exists(xtc_file) and os.path.exists(gro_file)):
            print(f"WARNING: Missing {xtc_file} or {gro_file}, skipping chunk {chunk_i}.")
            return
        traj = md.load_xtc(xtc_file, top=gro_file)
        phi_indices, phi_v, psi_indices, psi_v, chi1_indices, chi1_v, chi2_indices, chi2_v, om_indices, om_v = \
            compute_phi_psi_chi1chi2_omega(traj)
        tE, pE = parse_potential(edr_file)
        with open(LOWEST_ENERGY_FILENAME, "r") as f:
            lowest_energy = float(f.read().strip())
        global CONFORMATION_STATS_FULL, CONFORMATION_STATS_NO_CHI2
        global CONFORMATION_STATS_SUBSET, CONFORMATION_STATS_SUBSET_NO_CHI2
        com_list = []
        for fi in range(traj.n_frames):
            pot_val = nearest_potential(traj.time[fi], tE, pE)
            weight = np.exp(-BETA * (pot_val - lowest_energy))
            if DEBUG:
                phi_angles_deg = np.degrees(phi_v[fi])
                psi_angles_deg = np.degrees(psi_v[fi])
                print(f"Frame {fi}: phi angles (deg): {phi_angles_deg}")
                print(f"Frame {fi}: psi angles (deg): {psi_angles_deg}")
            full_key, full_no_chi2, subset_key, subset_no_chi2 = classify_conformation(
                traj, fi,
                phi_indices, phi_v, psi_indices, psi_v,
                chi1_indices, chi1_v, chi2_indices, chi2_v,
                om_indices, om_v,
                rotamer_dict
            )
            if DEBUG:
                print(f"Chunk {chunk_i}, Frame {fi}:")
                print(f"   Full Key = {full_key}")
                print(f"   Full Key (no χ₂) = {full_no_chi2}")
                print(f"   Subset Key = {subset_key}")
                print(f"   Subset Key (no χ₂) = {subset_no_chi2}")
            for d, key in [(CONFORMATION_STATS_FULL, full_key),
                           (CONFORMATION_STATS_NO_CHI2, full_no_chi2),
                           (CONFORMATION_STATS_SUBSET, subset_key),
                           (CONFORMATION_STATS_SUBSET_NO_CHI2, subset_no_chi2)]:
                oldc, oldnum, oldden = d.get(key, (0, 0.0, 0.0))
                d[key] = (oldc + 1, oldnum + pot_val * weight, oldden + weight)
            # Compute COM for this frame using selected COM_ANALYSIS_RESIDUES.
            com = compute_com_for_frame(traj, fi, COM_ANALYSIS_RESIDUES)
            if com is not None:
                com_list.append(com)
        print(f"Chunk {chunk_i}: Processed {traj.n_frames} frames")
        print(f"    Unique full keys: {len(CONFORMATION_STATS_FULL)}")
        print(f"    Unique full (no χ₂) keys: {len(CONFORMATION_STATS_NO_CHI2)}")
        print(f"    Unique subset keys: {len(CONFORMATION_STATS_SUBSET)}")
        print(f"    Unique subset (no χ₂) keys: {len(CONFORMATION_STATS_SUBSET_NO_CHI2)}")
        
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        np.save(MASTER_NPY_FULL, CONFORMATION_STATS_FULL)
        np.save(MASTER_NPY_NO_CHI2, CONFORMATION_STATS_NO_CHI2)
        np.save(MASTER_NPY_SUBSET, CONFORMATION_STATS_SUBSET)
        np.save(MASTER_NPY_SUBSET_NO_CHI2, CONFORMATION_STATS_SUBSET_NO_CHI2)
        
        unique_full[chunk_i] = len(CONFORMATION_STATS_FULL)
        unique_no_chi2[chunk_i] = len(CONFORMATION_STATS_NO_CHI2)
        unique_subset[chunk_i] = len(CONFORMATION_STATS_SUBSET)
        unique_subset_no_chi2[chunk_i] = len(CONFORMATION_STATS_SUBSET_NO_CHI2)
        np.save(UNIQUE_KEYS_NPY_FULL, unique_full)
        np.save(UNIQUE_KEYS_NPY_NO_CHI2, unique_no_chi2)
        np.save(UNIQUE_KEYS_NPY_SUBSET, unique_subset)
        np.save(UNIQUE_KEYS_NPY_SUBSET_NO_CHI2, unique_subset_no_chi2)
        
        if com_list:
            COM_VALUES[chunk_i] = np.array(com_list)
            np.save(COM_NPY_FILE, COM_VALUES)
            print(f"Chunk {chunk_i}: COM analysis updated with {len(com_list)} frames.")
        
        if chunk_i >= max(EQUILIBRATION_END_CHUNK, 1005) and (chunk_i - 5) % 1000 == 0:
            group_number = (chunk_i - 5) // 1000
            print(f"Chunk {chunk_i}: Group boundary reached; moving and zipping group {group_number}.")
            move_group_files(group_number)
            zip_group_files(group_number)
        if chunk_i >= EQUILIBRATION_END_CHUNK and chunk_i % 100 == 0:
            snapshot_master_full = os.path.join(OUTPUT_DIR, f"snapshot_master_full_{chunk_i}.npy")
            np.save(snapshot_master_full, CONFORMATION_STATS_FULL)
            print(f"Snapshot saved for chunk {chunk_i}.")
    except Exception as e:
        print(f"ERROR analyzing chunk {chunk_i} in background: {e}")

##############################################################################
#                   RUN CHUNK AND UPDATE LOWEST ENERGY                       #
##############################################################################
def run_chunk(i, prev_prefix):
    grompp_and_mdrun(i, prev_prefix)

def update_lowest_energy(chunk_i):
    step_prefix = f"step{chunk_i}"
    xtc_file = f"{step_prefix}.xtc"
    gro_file = f"{step_prefix}.gro"
    edr_file = f"{step_prefix}.edr"
    if not (os.path.exists(xtc_file) and os.path.exists(gro_file) and os.path.exists(edr_file)):
        print(f"WARNING: Missing files for chunk {chunk_i}, cannot update lowest energy.")
        return
    traj = md.load_xtc(xtc_file, top=gro_file)
    _, potentials = parse_potential(edr_file)
    if len(potentials) == 0:
        print(f"WARNING: No potentials found for chunk {chunk_i}, skipping lowest energy update.")
        return
    current_lowest = potentials.min()
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    lowest_energy_path = LOWEST_ENERGY_FILENAME
    if os.path.exists(lowest_energy_path):
        with open(lowest_energy_path, "r") as f:
            stored_lowest = float(f.read().strip())
        new_lowest = min(stored_lowest, current_lowest)
    else:
        new_lowest = current_lowest
    with open(lowest_energy_path, "w") as f:
        f.write(f"{new_lowest:.6f}")
    if DEBUG:
        print(f"Chunk {chunk_i}: Updated lowest energy to {new_lowest:.6f}")

##############################################################################
#                                  MAIN FUNCTION                             #
##############################################################################
def main():
    fresh_run = False
    equil_xtc = EQUI_PREFIX + ".xtc"
    if not os.path.exists(equil_xtc):
        print(f"Equilibration file {equil_xtc} not found. Running README script...")
        ret = subprocess.run("./README", shell=True)
        if ret.returncode != 0:
            print("Error: README script did not complete successfully.")
            sys.exit(1)
        # Explicitly remove step1.gro and step2.gro if they exist
        for gro_file in ["step1.gro", "step2.gro"]:
            if os.path.exists(gro_file):
                os.remove(gro_file)
                print(f"Removed stray file: {gro_file}")
        fresh_run = True
        last_chunk = 0
        prev_prefix = EQUI_PREFIX
    else:
        last_chunk, prev_prefix = get_last_completed_chunk()

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    global CONFORMATION_STATS_FULL, CONFORMATION_STATS_NO_CHI2
    global CONFORMATION_STATS_SUBSET, CONFORMATION_STATS_SUBSET_NO_CHI2

    rotamer_dict = {}
    if os.path.exists(ROTAMER_CONFIG_FILE):
        with open(ROTAMER_CONFIG_FILE, "r") as f:
            rotamer_dict = json.load(f)

    try:
        gro_file = EQUI_PREFIX + ".gro"
        if os.path.exists(gro_file):
            topo_traj = md.load(gro_file)
            print("DEBUG: Residues in the analysis window (FULL_ANALYSIS_RESIDUES):")
            for res in list(topo_traj.topology.residues):
                if res.index not in FULL_ANALYSIS_RESIDUES:
                    continue
                rnum = res.index
                rname = res.name
                rama_csv = f"rama_{(rnum-1):02d}{rname}.csv" if rnum > 0 else "None (extra residue)"
                print(f"Residue {rnum} ({rname}): Rama CSV = {rama_csv}")
                if rname in rotamer_dict:
                    chi1_boundaries = rotamer_dict[rname].get("chi1", {}).get("boundaries", "None")
                    chi2_boundaries = rotamer_dict[rname].get("chi2", {}).get("boundaries", "None")
                    print(f"   chi1 boundaries: {chi1_boundaries}")
                    print(f"   chi2 boundaries: {chi2_boundaries}")
                else:
                    print("   No rotamer config for this residue.")
        else:
            print("DEBUG: Equilibration GRO file not found; skipping startup residue debug print.")
    except Exception as e:
        print(f"DEBUG: Error during startup residue debug print: {e}")

    all_files = glob.glob("step*.*")
    groups_to_move = {}
    for f in all_files:
        m = re.search(r"step(\d+)\.", f)
        if m:
            chunk_num = int(m.group(1))
            group_num = (chunk_num - 1) // 1000 + 1
            if group_num not in groups_to_move or chunk_num > groups_to_move[group_num]:
                groups_to_move[group_num] = chunk_num
    for group, max_chunk in sorted(groups_to_move.items()):
        print(f"Group {group} reached boundary (max chunk {max_chunk}); moving files." if max_chunk >= group * 1000 + 5 else f"Group {group} max chunk {max_chunk} below boundary; leaving files.")
        if max_chunk >= group * 1000 + 5:
            move_group_files(group)

    for file, var in [(MASTER_NPY_FULL, "full"),
                      (MASTER_NPY_NO_CHI2, "no_chi2"),
                      (MASTER_NPY_SUBSET, "subset"),
                      (MASTER_NPY_SUBSET_NO_CHI2, "subset_no_chi2")]:
        if os.path.exists(file):
            try:
                data = np.load(file, allow_pickle=True).item()
                if var == "full":
                    CONFORMATION_STATS_FULL = data
                elif var == "no_chi2":
                    CONFORMATION_STATS_NO_CHI2 = data
                elif var == "subset":
                    CONFORMATION_STATS_SUBSET = data
                elif var == "subset_no_chi2":
                    CONFORMATION_STATS_SUBSET_NO_CHI2 = data
                print(f"Loaded previous data from {file}.")
            except Exception as e:
                print(f"Error loading {file}: {e}. Starting with empty state.")

    # Determine starting chunk.
    if fresh_run:
        start_chunk = 1
        prev_prefix = EQUI_PREFIX
        print("Fresh run detected: forcing start at chunk 1.")
    else:
        start_chunk = last_chunk + 1

    if start_chunk > N_CHUNKS:
        print("All chunks already completed. Exiting.")
        return

    print(f"Resuming from chunk {start_chunk} (previous completed: {last_chunk}).")
    print(f"Starting main() with N_CHUNKS={N_CHUNKS}.")

    analysis_futures = []
    with ThreadPoolExecutor() as executor:
        for i in range(start_chunk, N_CHUNKS + 1):
            print(f"\n=== Running chunk {i} ===")
            t0 = time.time()
            print(f"Running grompp_and_mdrun for chunk {i} with prev_prefix={prev_prefix}...")
            run_chunk(i, prev_prefix)
            t1 = time.time()
            sec = t1 - t0
            cpd = 86400.0 / sec
            print(f"Chunk {i} finished in {sec:.2f}s => {cpd:.2f} chunks/day")
            if i < EQUILIBRATION_END_CHUNK:
                update_lowest_energy(i)
                print(f"Chunk {i}: Still in equilibration; lowest energy updated, analysis skipped.")
            else:
                fut = executor.submit(analyze_chunk_bg, i, rotamer_dict)
                analysis_futures.append(fut)
                unique_full[i] = len(CONFORMATION_STATS_FULL)
                unique_no_chi2[i] = len(CONFORMATION_STATS_NO_CHI2)
                unique_subset[i] = len(CONFORMATION_STATS_SUBSET)
                unique_subset_no_chi2[i] = len(CONFORMATION_STATS_SUBSET_NO_CHI2)
                np.save(UNIQUE_KEYS_NPY_FULL, unique_full)
                np.save(UNIQUE_KEYS_NPY_NO_CHI2, unique_no_chi2)
                np.save(UNIQUE_KEYS_NPY_SUBSET, unique_subset)
                np.save(UNIQUE_KEYS_NPY_SUBSET_NO_CHI2, unique_subset_no_chi2)
                print(f"Chunk {i}: Unique-key plots updated.")
            if i >= max(EQUILIBRATION_END_CHUNK, 1005) and (i - 5) % 1000 == 0:
                group_number = (i - 5) // 1000
                print(f"Chunk {i}: Group boundary reached; moving and zipping group {group_number}.")
                move_group_files(group_number)
                zip_group_files(group_number)
            if i >= EQUILIBRATION_END_CHUNK and i % 100 == 0:
                snapshot_master_full = os.path.join(OUTPUT_DIR, f"snapshot_master_full_{i}.npy")
                np.save(snapshot_master_full, CONFORMATION_STATS_FULL)
                print(f"Snapshot saved for chunk {i}.")
            prev_prefix = f"step{i}"
        for future in analysis_futures:
            future.result()

    print("All chunks and analyses completed. Exiting.")

if __name__ == "__main__":
    main()

